import { registerPlugin } from '@capacitor/core';

var MXOAssetResponseCodeSentiment;
(function (MXOAssetResponseCodeSentiment) {
    MXOAssetResponseCodeSentiment["POSITIVE"] = "POSITIVE";
    MXOAssetResponseCodeSentiment["NEUTRAL"] = "NEUTRAL";
    MXOAssetResponseCodeSentiment["NEGATIVE"] = "NEGATIVE";
    MXOAssetResponseCodeSentiment["UNKNOWN"] = "UNKNOWN";
})(MXOAssetResponseCodeSentiment || (MXOAssetResponseCodeSentiment = {}));
var MXOAssetResponseCodeSentiment$1 = MXOAssetResponseCodeSentiment;

var MXOAssetResponseTarget;
(function (MXOAssetResponseTarget) {
    MXOAssetResponseTarget["IN_APP"] = "IN_APP";
    MXOAssetResponseTarget["EXTERNAL"] = "EXTERNAL";
    MXOAssetResponseTarget["CONTEXT"] = "CONTEXT";
    MXOAssetResponseTarget["UNKNOWN"] = "UNKNOWN";
})(MXOAssetResponseTarget || (MXOAssetResponseTarget = {}));
var MXOAssetResponseTarget$1 = MXOAssetResponseTarget;

var MXOCaptureElementType;
(function (MXOCaptureElementType) {
    MXOCaptureElementType["TEXT_FIELD"] = "TEXT_FIELD";
    MXOCaptureElementType["CHECKBOX_RADIO"] = "CHECKBOX_RADIO";
    MXOCaptureElementType["DISPLAY_ELEM"] = "DISPLAY_ELEM";
    MXOCaptureElementType["DROP_DOWN"] = "DROP_DOWN";
})(MXOCaptureElementType || (MXOCaptureElementType = {}));
var MXOCaptureElementType$1 = MXOCaptureElementType;

var MXOCapturePhase;
(function (MXOCapturePhase) {
    MXOCapturePhase["LOAD"] = "LOAD";
    MXOCapturePhase["ONCLICK"] = "ONCLICK";
    MXOCapturePhase["PARAMETER"] = "PARAMETER";
})(MXOCapturePhase || (MXOCapturePhase = {}));
var MXOCapturePhase$1 = MXOCapturePhase;

var MXOLogComponent;
(function (MXOLogComponent) {
    MXOLogComponent["ANY"] = "ANY";
    MXOLogComponent["NETWORKING"] = "NETWORKING";
    MXOLogComponent["INTERACTION"] = "INTERACTION";
    MXOLogComponent["NONE"] = "NONE";
})(MXOLogComponent || (MXOLogComponent = {}));
var MXOLogComponent$1 = MXOLogComponent;

var MXOLogLevel;
(function (MXOLogLevel) {
    MXOLogLevel["VERBOSE"] = "VERBOSE";
    /**
     * Debug details might be logged.
     */
    MXOLogLevel["DEBUG"] = "DEBUG";
    /**
     * Errors might be logged.
     */
    MXOLogLevel["ERROR"] = "ERROR";
    /**
     * Warnings might be logged.
     */
    MXOLogLevel["WARN"] = "WARN";
    /**
     * Info details might be logged.
     */
    MXOLogLevel["INFO"] = "INFO";
    /**
     * Nothing is logged.
     */
    MXOLogLevel["NONE"] = "NONE";
})(MXOLogLevel || (MXOLogLevel = {}));
var MXOLogLevel$1 = MXOLogLevel;

var MXOMimeType;
(function (MXOMimeType) {
    MXOMimeType["JSON"] = "JSON";
    MXOMimeType["TXT"] = "TXT";
    MXOMimeType["HTML"] = "HTML";
    MXOMimeType["XML"] = "XML";
    MXOMimeType["EXTERNAL"] = "EXTERNAL";
    MXOMimeType["UNKNOWN"] = "UNKNOWN";
})(MXOMimeType || (MXOMimeType = {}));
var MXOMimeType$1 = MXOMimeType;

var MXOOptimizationPointDirectives;
(function (MXOOptimizationPointDirectives) {
    MXOOptimizationPointDirectives["REPLACE"] = "REPLACE";
    MXOOptimizationPointDirectives["BEFORE"] = "BEFORE";
    MXOOptimizationPointDirectives["AFTER"] = "AFTER";
})(MXOOptimizationPointDirectives || (MXOOptimizationPointDirectives = {}));
var MXOOptimizationPointDirectives$1 = MXOOptimizationPointDirectives;

var MXOOptInOptions;
(function (MXOOptInOptions) {
    MXOOptInOptions["CITY_COUNTRY_DETECTION"] = "CITY_COUNTRY_DETECTION";
    MXOOptInOptions["INTERACTION_TRACKING"] = "INTERACTION_TRACKING";
    MXOOptInOptions["KEYCHAIN_TID_STORAGE"] = "KEYCHAIN_TID_STORAGE";
})(MXOOptInOptions || (MXOOptInOptions = {}));
var MXOOptInOptions$1 = MXOOptInOptions;

var MXOPropositionType;
(function (MXOPropositionType) {
    MXOPropositionType["PRODUCT"] = "PRODUCT";
    MXOPropositionType["SERVICE"] = "SERVICE";
})(MXOPropositionType || (MXOPropositionType = {}));
var MXOPropositionType$1 = MXOPropositionType;

var MXOCaptureType;
(function (MXOCaptureType) {
    MXOCaptureType["ATTRIBUTE"] = "ATTRIBUTE";
    MXOCaptureType["TEXT"] = "TEXT";
    MXOCaptureType["VALUE"] = "VALUE";
    MXOCaptureType["COOKIE"] = "COOKIE";
})(MXOCaptureType || (MXOCaptureType = {}));
var MXOCaptureType$1 = MXOCaptureType;

const MedalliaMXO = registerPlugin('MedalliaMXO', {});

export { MXOAssetResponseCodeSentiment$1 as MXOAssetResponseCodeSentiment, MXOAssetResponseTarget$1 as MXOAssetResponseTarget, MXOCaptureElementType$1 as MXOCaptureElementType, MXOCapturePhase$1 as MXOCapturePhase, MXOCaptureType$1 as MXOCaptureType, MXOLogComponent$1 as MXOLogComponent, MXOLogLevel$1 as MXOLogLevel, MXOMimeType$1 as MXOMimeType, MXOOptInOptions$1 as MXOOptInOptions, MXOOptimizationPointDirectives$1 as MXOOptimizationPointDirectives, MXOPropositionType$1 as MXOPropositionType, MedalliaMXO as default };
