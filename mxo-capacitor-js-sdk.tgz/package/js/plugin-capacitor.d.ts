declare enum MXOLogComponent {
    ANY = "ANY",
    NETWORKING = "NETWORKING",
    INTERACTION = "INTERACTION",
    NONE = "NONE"
}

declare enum MXOLogLevel {
    VERBOSE = "VERBOSE",
    /**
     * Debug details might be logged.
     */
    DEBUG = "DEBUG",
    /**
     * Errors might be logged.
     */
    ERROR = "ERROR",
    /**
     * Warnings might be logged.
     */
    WARN = "WARN",
    /**
     * Info details might be logged.
     */
    INFO = "INFO",
    /**
     * Nothing is logged.
     */
    NONE = "NONE"
}

interface MXOLoggingConfiguration {
    readonly levels: MXOLogLevel[] | null;
    readonly components: MXOLogComponent[] | null;
}

interface MXOError {
    readonly message: string | null;
    readonly apiName: string | null;
    readonly cause: string | null;
}

interface MXOResult<T> {
    readonly value: T | null | MXOError;
}

interface MXOConfiguration {
    readonly siteKey: string | null;
    readonly touchpoint: string | null;
    readonly host: string | null;
    readonly mode: number | null;
}

interface MXOAutomaticInteractionTrackingConfiguration {
    readonly disableInteractionTracking: boolean;
    readonly disableOutboundLinkTracking: boolean;
    readonly disableWebViewInteractionTracking: boolean;
}

interface MXOIdentityTransferUriMatcher {
    readonly value: URL | string;
}

interface MXOIdentityTransferConfiguration {
    readonly disableIdentityTransfer: boolean;
    readonly includeList: MXOIdentityTransferUriMatcher[];
    readonly excludeList: MXOIdentityTransferUriMatcher[];
}

declare enum MXOOptInOptions {
    CITY_COUNTRY_DETECTION = "CITY_COUNTRY_DETECTION",
    INTERACTION_TRACKING = "INTERACTION_TRACKING",
    KEYCHAIN_TID_STORAGE = "KEYCHAIN_TID_STORAGE"
}

interface MXOOptOutConfiguration {
    readonly optOut: boolean;
    readonly optInOptions: MXOOptInOptions[];
}

interface MXOLocation {
    readonly latitude: number;
    readonly longitude: number;
    readonly horizontalAccuracy: number;
    readonly timestamp: number;
}

interface MXOInteractionRequest {
    readonly interaction: string | null;
    readonly properties: Record<string, string> | null;
}

declare enum MXOMimeType {
    JSON = "JSON",
    TXT = "TXT",
    HTML = "HTML",
    XML = "XML",
    EXTERNAL = "EXTERNAL",
    UNKNOWN = "UNKNOWN"
}

declare enum MXOAssetResponseCodeSentiment {
    POSITIVE = "POSITIVE",
    NEUTRAL = "NEUTRAL",
    NEGATIVE = "NEGATIVE",
    UNKNOWN = "UNKNOWN"
}

declare enum MXOAssetResponseTarget {
    IN_APP = "IN_APP",
    EXTERNAL = "EXTERNAL",
    CONTEXT = "CONTEXT",
    UNKNOWN = "UNKNOWN"
}

interface MXOAssetResponse {
    readonly code: string | null;
    readonly sentiment: MXOAssetResponseCodeSentiment;
    readonly label: string | null;
    readonly imageUrl: string | URL | null;
    readonly targetUrl: string | URL | null;
    readonly target: MXOAssetResponseTarget | null;
}

interface MXOAsset {
    readonly markup: string | null;
    readonly responses: MXOAssetResponse[];
    readonly mimeType: MXOMimeType;
    readonly contentUrl: string | null;
}

declare enum MXOPropositionType {
    PRODUCT = "PRODUCT",
    SERVICE = "SERVICE"
}

interface MXOProposition {
    readonly name: string | null;
    readonly code: string | null;
    readonly type: MXOPropositionType;
}

interface MXOAction {
    readonly name: string | null;
    readonly asset: MXOAsset | null;
    readonly proposition: MXOProposition | null;
}

declare enum MXOOptimizationPointDirectives {
    REPLACE = "REPLACE",
    BEFORE = "BEFORE",
    AFTER = "AFTER"
}

interface MXOOptimizationPoint {
    readonly path: string | null;
    readonly actions: MXOAction[];
    readonly directives: MXOOptimizationPointDirectives | null;
}

interface MXOCaptureActivityPoint {
    readonly id: string | null;
    readonly path: string | null;
}

declare enum MXOCaptureElementType {
    TEXT_FIELD = "TEXT_FIELD",
    CHECKBOX_RADIO = "CHECKBOX_RADIO",
    DISPLAY_ELEM = "DISPLAY_ELEM",
    DROP_DOWN = "DROP_DOWN"
}

declare enum MXOCaptureType {
    ATTRIBUTE = "ATTRIBUTE",
    TEXT = "TEXT",
    VALUE = "VALUE",
    COOKIE = "COOKIE"
}

declare enum MXOCapturePhase {
    LOAD = "LOAD",
    ONCLICK = "ONCLICK",
    PARAMETER = "PARAMETER"
}

interface MXOCaptureAttributePoint {
    readonly id: string | null;
    readonly path: string | null;
    readonly elementType: MXOCaptureElementType | null;
    readonly elementName: string | null;
    readonly elementAttributeName: string | null;
    readonly captureDelay: number;
    readonly captureType: MXOCaptureType | null;
    readonly capturePhase: MXOCapturePhase | null;
}

interface MXOInteractionResponse {
    readonly interaction: string;
    readonly tid: string | null;
    readonly isSuccess: boolean;
    readonly optimizationPoints: MXOOptimizationPoint[];
    readonly captureActivityPoints: MXOCaptureActivityPoint[];
    readonly captureAttributePoints: MXOCaptureAttributePoint[];
}

interface MXOResponseCodeRequest {
    readonly interaction: string;
    readonly responseCode: string;
}

interface MXOValue<T> {
    readonly value: T;
}

interface MedalliaMXOPlugin {
    getConfiguration(): Promise<MXOResult<MXOConfiguration>>;
    setConfiguration(config: MXOConfiguration | null): Promise<MXOResult<null>>;
    getOptOutConfiguration(): Promise<MXOResult<MXOOptOutConfiguration>>;
    setOptOutConfiguration(config: MXOOptOutConfiguration | null): Promise<MXOResult<null>>;
    getLoggingConfiguration(): Promise<MXOResult<MXOLoggingConfiguration>>;
    setLoggingConfiguration(config: MXOLoggingConfiguration | null): Promise<MXOResult<null>>;
    getAutomaticInteractionTrackingConfiguration(): Promise<MXOResult<MXOAutomaticInteractionTrackingConfiguration>>;
    setAutomaticInteractionTrackingConfiguration(config: MXOAutomaticInteractionTrackingConfiguration | null): Promise<MXOResult<null>>;
    getIdentityTransferConfiguration(): Promise<MXOResult<MXOIdentityTransferConfiguration>>;
    setIdentityTransferConfiguration(config: MXOIdentityTransferConfiguration | null): Promise<MXOResult<null>>;
    generateIdentityTransferUrl(url: MXOValue<URL | string>): Promise<MXOResult<string>>;
    getVersion(): Promise<MXOResult<string>>;
    getTid(): Promise<MXOResult<string>>;
    clearTid(): Promise<MXOResult<null>>;
    processLocation(location: MXOLocation): Promise<MXOResult<null>>;
    processDeeplink(url: MXOValue<URL | string>): Promise<MXOResult<null>>;
    sendInteraction(request: MXOInteractionRequest): Promise<MXOResult<MXOInteractionResponse>>;
    sendProperties(request: MXOInteractionRequest): Promise<MXOResult<MXOInteractionResponse>>;
    sendInteractionResponseCode(request: MXOResponseCodeRequest | null): Promise<MXOResult<MXOInteractionResponse>>;
    sendInteractionForOutboundLink(mxoUrl: MXOValue<URL | string>): Promise<MXOResult<null>>;
    processResponse(response: MXOInteractionResponse): Promise<MXOResult<null>>;
}

declare const MedalliaMXO: MedalliaMXOPlugin;

export { type MXOAction, type MXOAsset, type MXOAssetResponse, MXOAssetResponseCodeSentiment, MXOAssetResponseTarget, type MXOAutomaticInteractionTrackingConfiguration, type MXOCaptureActivityPoint, type MXOCaptureAttributePoint, MXOCaptureElementType, MXOCapturePhase, MXOCaptureType, type MXOConfiguration, type MXOError, type MXOIdentityTransferConfiguration, type MXOIdentityTransferUriMatcher, type MXOInteractionRequest, type MXOInteractionResponse, type MXOLocation, MXOLogComponent, MXOLogLevel, type MXOLoggingConfiguration, MXOMimeType, MXOOptInOptions, type MXOOptOutConfiguration, type MXOOptimizationPoint, MXOOptimizationPointDirectives, type MXOProposition, MXOPropositionType, type MXOResponseCodeRequest, type MXOResult, type MXOValue, MedalliaMXO as default };
