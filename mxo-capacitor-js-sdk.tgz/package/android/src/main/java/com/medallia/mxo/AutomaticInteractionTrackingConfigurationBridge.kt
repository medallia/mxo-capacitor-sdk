/* 
 *  Copyright (c) 2024 Medallia. Use subject to licensing terms. 
 */
package com.medallia.mxo

import android.annotation.SuppressLint
import com.medallia.mxo.automatic.MXOAutomaticInteractionTrackingConfiguration
import org.json.JSONObject

@Suppress("TooGenericExceptionCaught")
@SuppressLint("NewApi")
internal object AutomaticInteractionTrackingConfigurationBridge {
    const val KEY_DISABLE_INTERACTION_TRACKING = "disableInteractionTracking"
    const val KEY_DISABLE_OUTBOUND_LINK_TRACKING = "disableOutboundLinkTracking"
    const val KEY_DISABLE_WEB_VIEW_INTERACTION_TRACKING = "disableWebViewInteractionTracking"

    object Setter : ApiBridge<MXOAutomaticInteractionTrackingConfiguration>() {
        override fun adaptJson(jsObject: JSONObject?): MXOAutomaticInteractionTrackingConfiguration? =
            jsObject?.let { js ->
                (
                    mxoAutomaticInteractionTrackingConfiguration?.builder()
                        ?: MXOAutomaticInteractionTrackingConfiguration.Builder()
                ).apply {
                    if (js.has(KEY_DISABLE_INTERACTION_TRACKING)) {
                        disableInteractionTracking = js.getBoolean(KEY_DISABLE_INTERACTION_TRACKING)
                    }
                    if (js.has(KEY_DISABLE_OUTBOUND_LINK_TRACKING)) {
                        disableOutboundLinkTracking = js.getBoolean(KEY_DISABLE_OUTBOUND_LINK_TRACKING)
                    }
                    if (js.has(KEY_DISABLE_WEB_VIEW_INTERACTION_TRACKING)) {
                        disableWebViewInteractionTracking =
                            js.getBoolean(KEY_DISABLE_WEB_VIEW_INTERACTION_TRACKING)
                    }
                }.build()
            }

        override suspend fun invokeInternal(args: MXOAutomaticInteractionTrackingConfiguration?): ApiResult =
            try {
                mxoAutomaticInteractionTrackingConfiguration = args
                LOGGER.verbose { "Set MXO Automatic Interaction Tracking Configuration:\n $args" }
                ApiResult.NullApiResult
            } catch (e: Exception) {
                LOGGER.error(e) { "Set MXO Automatic Interaction Tracking Configuration Failed." }
                ApiResult.ErrorApiResult(e)
            }
    }

    object Getter : ApiBridge<Unit>() {
        override fun adaptJson(jsObject: JSONObject?): Unit? = null

        override suspend fun invokeInternal(args: Unit?): ApiResult =
            try {
                val js =
                    mxoAutomaticInteractionTrackingConfiguration?.let { config ->
                        JSONObject().apply {
                            put(KEY_DISABLE_INTERACTION_TRACKING, config.disableInteractionTracking)
                            put(KEY_DISABLE_OUTBOUND_LINK_TRACKING, config.disableOutboundLinkTracking)
                            put(KEY_DISABLE_WEB_VIEW_INTERACTION_TRACKING, config.disableWebViewInteractionTracking)
                        }
                    }
                LOGGER.verbose { "Get MXO Automatic Interaction Tracking Configuration:\n $js" }
                ApiResult.JSONObjectApiResult(js)
            } catch (e: Exception) {
                LOGGER.error(e) { "Get MXO Automatic Interaction Tracking Configuration Failed." }
                ApiResult.ErrorApiResult(e)
            }
    }
}
