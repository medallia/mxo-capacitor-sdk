/* 
 *  Copyright (c) 2024 Medallia. Use subject to licensing terms. 
 */
package com.medallia.mxo

import android.annotation.SuppressLint
import org.json.JSONObject

@Suppress("TooGenericExceptionCaught")
@SuppressLint("NewApi")
internal object TidBridge {
    object Clear : ApiBridge<Unit>() {
        override fun adaptJson(jsObject: JSONObject?): Unit? = null

        override suspend fun invokeInternal(args: Unit?): ApiResult =
            try {
                mxoClearTid()
                LOGGER.verbose { "Clear Tid" }
                ApiResult.NullApiResult
            } catch (e: Exception) {
                LOGGER.error(e) { "Clear Tid Failed." }
                ApiResult.ErrorApiResult(e)
            }
    }

    object Getter : ApiBridge<Unit>() {
        override fun adaptJson(jsObject: JSONObject?): Unit? = null

        override suspend fun invokeInternal(args: Unit?): ApiResult =
            try {
                val value = mxoGetTid(true)
                LOGGER.verbose { "Get Tid:\n $value" }
                ApiResult.StringApiResult(value)
            } catch (e: Exception) {
                LOGGER.error(e) { "Get Tid Failed." }
                ApiResult.ErrorApiResult(e)
            }
    }
}
