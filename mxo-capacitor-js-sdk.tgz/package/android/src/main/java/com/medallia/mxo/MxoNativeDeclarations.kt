/* 
 *  Copyright (c) 2024 Medallia. Use subject to licensing terms. 
 */
package com.medallia.mxo

import com.medallia.mxo.interactions.MXOInteractionRequest
import com.medallia.mxo.interactions.MXOInteractionResponse
import com.medallia.mxo.interactions.MXOResponseCodeRequest

/**
 * This wrapper is needed for mocking purposes in unit tests to avoid ambiguity.
 *
 * Send interaction to the MXO API.
 *
 * @param throwErrors [Boolean] true to enable throwable errors. When enabled, wrap this method in a `try/catch` block.
 * @param mxoInteractionRequest [MXOInteractionRequest] to send.
 * @return response [MXOInteractionResponse] result of request
 * @throws [MXO APIError] or [MXOErrorSdk] if [throwErrors] == true.
 */
internal suspend fun mxoSendInteractionWrapper(
    throwErrors: Boolean = false,
    mxoInteractionRequest: MXOInteractionRequest,
): MXOInteractionResponse? = mxoSendInteraction(throwErrors, mxoInteractionRequest)

/**
 * This wrapper is needed for mocking purposes in unit tests to avoid ambiguity.
 *
 * Send properties to the MXO API.
 *
 * @param throwErrors [Boolean] true to enable throwable errors. When enabled, wrap this method in a `try/catch` block.
 * @param mxoInteractionRequest [MXOInteractionRequest] to send.
 * @return response [MXOInteractionResponse] result of request
 * @throws [MXO APIError] or [MXOErrorSdk] if [throwErrors] == true.
 */
internal suspend fun mxoSendPropertiesWrapper(
    throwErrors: Boolean = false,
    mxoInteractionRequest: MXOInteractionRequest,
): MXOInteractionResponse? = mxoSendProperties(throwErrors, mxoInteractionRequest)

/**
 * This wrapper is needed for mocking purposes in unit tests to avoid ambiguity.
 *
 * Send interaction Response Code to the MXO API.
 *
 * @param throwErrors [Boolean] true to enable throwable errors. When enabled, wrap this method in a `try/catch` block.
 * @param MXOResponseCodeRequest [MXOResponseCodeRequest] to send.
 * @return response [MXOInteractionResponse] result of request
 * @throws [MXO APIError] or [MXOErrorSdk] if [throwErrors] == true.
 */
internal suspend fun mxoSendInteractionResponseCodeWrapper(
    throwErrors: Boolean = false,
    mxoResponseCodeRequest: MXOResponseCodeRequest,
): MXOInteractionResponse? = mxoSendInteractionResponseCode(throwErrors, mxoResponseCodeRequest)
