/* 
 *  Copyright (c) 2024 Medallia. Use subject to licensing terms. 
 */
package com.medallia.mxo

import android.annotation.SuppressLint
import android.location.Location
import android.location.LocationManager
import org.json.JSONObject

@Suppress("TooGenericExceptionCaught")
@SuppressLint("NewApi")
internal object ProcessLocationBridge {
    const val KEY_LATITUDE = "latitude"
    const val KEY_LONGITUDE = "longitude"
    const val KEY_HORIZONTAL_ACCURACY = "horizontalAccuracy"
    const val KEY_TIMESTAMP = "timestamp"

    object Process : ApiBridge<Location>() {
        override fun adaptJson(jsObject: JSONObject?): Location? =
            jsObject?.let { js ->
                Location(LocationManager.GPS_PROVIDER).apply {
                    latitude = js.optDouble(KEY_LATITUDE, 0.0)
                    longitude = js.optDouble(KEY_LONGITUDE, 0.0)
                    accuracy = js.optDouble(KEY_HORIZONTAL_ACCURACY, 0.0).toFloat()
                    time = js.optLong(KEY_TIMESTAMP, 0L)
                }
            }

        override suspend fun invokeInternal(args: Location?): ApiResult =
            try {
                args?.process(true)
                LOGGER.verbose { "Process MXO Location:\n $args" }
                ApiResult.NullApiResult
            } catch (e: Exception) {
                LOGGER.error(e) { "Process MXO Location Failed." }
                ApiResult.ErrorApiResult(e)
            }
    }
}
