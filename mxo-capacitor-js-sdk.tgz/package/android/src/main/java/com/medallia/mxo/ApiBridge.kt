/* 
 *  Copyright (c) 2024 Medallia. Use subject to licensing terms. 
 */
package com.medallia.mxo

import org.json.JSONObject

@Suppress("TooGenericExceptionCaught")
internal abstract class ApiBridge<ARGS> {
    protected abstract fun adaptJson(jsObject: JSONObject?): ARGS?

    protected abstract suspend fun invokeInternal(args: ARGS?): ApiResult

    suspend fun invoke(bridgeCall: BridgeCall) {
        try {
            when (val result = invokeInternal(adaptJson(bridgeCall.jsonArgument))) {
                is ApiResult.ErrorApiResult,
                is ApiResult.StringApiResult,
                is ApiResult.NullApiResult,
                is ApiResult.JSONObjectApiResult,
                -> {
                    val jsonObject = result.jsonValue(bridgeCall.methodName)
                    bridgeCall.resolve(jsonObject)
                }
            }
        } catch (e: Exception) {
            LOGGER.error(e) { "${bridgeCall.methodName} failed." }
            bridgeCall.reject(
                "${bridgeCall.methodName} error.",
                jsonError {
                    apiName = bridgeCall.methodName
                    message = e.message
                    cause = e.cause?.message
                },
            )
        }
    }

    protected sealed class ApiResult {
        abstract fun jsonValue(apiName: String): JSONObject

        data object NullApiResult : ApiResult() {
            override fun jsonValue(apiName: String): JSONObject {
                val nothing: JSONObject? = null
                return mxoResult(nothing)
            }
        }

        data class ErrorApiResult(
            private val throwable: Throwable,
        ) : ApiResult() {
            override fun jsonValue(apiName: String): JSONObject =
                mxoResult(
                    jsonError {
                        this.apiName = apiName
                        message = throwable.message
                        cause = throwable.cause?.message
                    },
                )
        }

        data class StringApiResult(
            private val value: String?,
        ) : ApiResult() {
            override fun jsonValue(apiName: String): JSONObject = mxoResult(value)
        }

        data class JSONObjectApiResult(
            private val value: JSONObject?,
        ) : ApiResult() {
            override fun jsonValue(apiName: String): JSONObject = mxoResult(value)
        }
    }
}
