/* 
 *  Copyright (c) 2024 Medallia. Use subject to licensing terms. 
 */
package com.medallia.mxo

import org.json.JSONObject

internal interface BridgeCall {
    val jsonArgument: JSONObject?
    val methodName: String

    fun resolve(resolved: JSONObject)

    fun reject(
        msg: String,
        jsonError: JSONObject,
    )
}

internal fun bridgeCall(
    jsonArgument: JSONObject?,
    methodName: String,
    onResolve: (JSONObject) -> Unit,
    onReject: (String, JSONObject) -> Unit,
): BridgeCall = BridgeCallImpl(jsonArgument, methodName, onResolve, onReject)

private data class BridgeCallImpl(
    override val jsonArgument: JSONObject?,
    override val methodName: String,
    val onResolve: (JSONObject) -> Unit,
    val onReject: (String, JSONObject) -> Unit,
) : BridgeCall {
    override fun resolve(resolved: JSONObject) {
        onResolve(resolved)
    }

    override fun reject(
        msg: String,
        jsonError: JSONObject,
    ) {
        onReject(msg, jsonError)
    }
}
