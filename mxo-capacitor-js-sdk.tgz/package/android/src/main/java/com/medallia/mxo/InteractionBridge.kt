/* 
 *  Copyright (c) 2024 Medallia. Use subject to licensing terms. 
 */
package com.medallia.mxo

import android.annotation.SuppressLint
import com.medallia.mxo.interactions.MXOAction
import com.medallia.mxo.interactions.MXOAsset
import com.medallia.mxo.interactions.MXOAssetResponse
import com.medallia.mxo.interactions.MXOCaptureActivityPoint
import com.medallia.mxo.interactions.MXOCaptureAttributePoint
import com.medallia.mxo.interactions.MXOInteraction
import com.medallia.mxo.interactions.MXOInteractionRequest
import com.medallia.mxo.interactions.MXOInteractionResponse
import com.medallia.mxo.interactions.MXOOptimizationPoint
import com.medallia.mxo.interactions.MXOProposition
import com.medallia.mxo.interactions.MXOResponseCode
import com.medallia.mxo.interactions.MXOResponseCodeRequest
import com.medallia.mxo.interactions.mxoInteractionRequest
import com.medallia.mxo.interactions.mxoResponseCodeRequest
import com.medallia.mxo.internal.hybrid.hybridHydrateResponseFromJson
import com.medallia.mxo.internal.hybrid.hybridSerializeRealtimeCustomerInteractionData
import com.medallia.mxo.internal.hybrid.hybridSerializeSuccessInteractionData
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI
import java.net.URL

@Suppress("TooManyFunctions", "TooGenericExceptionCaught")
@SuppressLint("NewApi")
internal object InteractionBridge {
    private const val JSON_KEY_INTERACTION = "interaction"
    private const val JSON_KEY_PROPERTIES = "properties"
    private const val JSON_KEY_RESPONSE_CODE = "responseCode"
    private const val JSON_KEY_TID = "tid"
    private const val JSON_KEY_IS_SUCCESS = "isSuccess"
    private const val JSON_KEY_CAPTURE_ACTIVITY_POINTS = "captureActivityPoints"
    private const val JSON_KEY_CAPTURE_ATTRIBUTE_POINTS = "captureAttributePoints"
    private const val JSON_KEY_OPTIMIZATION_POINTS = "optimizationPoints"
    private const val JSON_KEY_BRAND_INTERACTION_DATA = "_brandInteractionData"
    private const val JSON_KEY_CUSTOMER_INTERACTION_DATA = "_customerInteractionData"

    private fun MXOInteractionResponse?.toJson(): JSONObject? =
        if (this == null) {
            null
        } else {
            JSONObject().apply {
                put(JSON_KEY_INTERACTION, interaction.value)
                put(JSON_KEY_TID, tid.orEmpty())
                put(JSON_KEY_IS_SUCCESS, isSuccess)
                put(JSON_KEY_CAPTURE_ACTIVITY_POINTS, captureActivityPointsJson())
                put(JSON_KEY_CAPTURE_ATTRIBUTE_POINTS, captureAttributesPointsJson())
                put(JSON_KEY_OPTIMIZATION_POINTS, optimizationPointsJson())
                put(JSON_KEY_BRAND_INTERACTION_DATA, hybridSerializeSuccessInteractionData())
                put(JSON_KEY_CUSTOMER_INTERACTION_DATA, hybridSerializeRealtimeCustomerInteractionData())
            }
        }

    private fun MXOInteractionResponse.captureActivityPointsJson() =
        captureActivityPoints
            .fold(JSONArray()) { result, item -> result.apply { put(item.toJson()) } }

    private fun MXOInteractionResponse.captureAttributesPointsJson() =
        captureAttributePoints
            .fold(JSONArray()) { result, item -> result.apply { put(item.toJson()) } }

    private fun MXOInteractionResponse.optimizationPointsJson() =
        optimizationPoints
            .fold(JSONArray()) { result, item -> result.apply { put(item.toJson()) } }

    private fun JSONObject?.toMxoRequest(): MXOInteractionRequest? =
        this?.let { js ->
            mxoInteractionRequest {
                if (js.has(JSON_KEY_INTERACTION)) {
                    interaction = MXOInteraction(URI.create(js.getString(JSON_KEY_INTERACTION)))
                }
                if (js.has(JSON_KEY_PROPERTIES)) {
                    val props = js.getJSONObject(JSON_KEY_PROPERTIES)
                    properties = props.keys().asSequence().associateWith { key -> props.get(key).toString() }
                }
            }
        }

    private fun MXOProposition.toJson(): JSONObject =
        JSONObject().apply {
            putOpt("name", name)
            putOpt("code", code)
            put("type", type.name)
        }

    private fun MXOAssetResponse.toJson(): JSONObject =
        JSONObject().apply {
            put("sentiment", sentiment.name)
            putOpt("label", label?.value)
            putOpt("imageUrl", imageUrl?.toString())
            putOpt("target", target?.name)
            putOpt("targetUrl", targetUrl?.toString())
            putOpt("code", code?.value)
        }

    private fun MXOCaptureActivityPoint.toJson(): JSONObject =
        JSONObject().apply {
            putOpt("id", id)
            putOpt("path", path)
        }

    private fun MXOAsset.toJson(): JSONObject =
        JSONObject().apply {
            putOpt("markup", markup)
            putOpt("mimeType", mimeType.name)
            put("responses", responses.fold(JSONArray()) { result, item -> result.apply { put(item.toJson()) } })
            putOpt("contentUrl", contentUrl?.toString())
        }

    private fun MXOAction.toJson(): JSONObject =
        JSONObject().apply {
            putOpt("name", name)
            putOpt("asset", asset?.toJson())
            putOpt("proposition", proposition?.toJson())
        }

    private fun MXOOptimizationPoint.toJson(): JSONObject =
        JSONObject().apply {
            putOpt("path", path)
            put("actions", actions.fold(JSONArray()) { result, item -> result.apply { put(item.toJson()) } })
            putOpt("directives", directives?.name)
        }

    private fun MXOCaptureAttributePoint.toJson(): JSONObject =
        JSONObject().apply {
            putOpt("id", id)
            putOpt("path", path)
            putOpt("captureType", captureType?.name)
            putOpt("captureDelay", captureDelay)
            putOpt("capturePhase", capturePhase?.name)
            putOpt("elementType", elementType?.name)
            putOpt("elementName", elementName)
            putOpt("elementAttributeName", elementAttributeName)
        }

    object SendInteraction : ApiBridge<MXOInteractionRequest>() {
        override fun adaptJson(jsObject: JSONObject?): MXOInteractionRequest? = jsObject.toMxoRequest()

        override suspend fun invokeInternal(args: MXOInteractionRequest?): ApiResult =
            try {
                LOGGER.verbose { "Send MXO Interaction:\n $args" }
                val interactionResponse =
                    args?.let {
                        mxoSendInteractionWrapper(true, args)
                    }
                LOGGER.verbose { "MXO Interaction Response:\n $interactionResponse" }
                ApiResult.JSONObjectApiResult(interactionResponse.toJson())
            } catch (e: Exception) {
                LOGGER.error(e) { "Send MXO Interaction Failed." }
                ApiResult.ErrorApiResult(e)
            }
    }

    object SendInteractionForOutboundLink : ApiBridge<URL>() {
        override fun adaptJson(jsObject: JSONObject?): URL? =
            jsObject?.let { js ->
                when (val opt = js.opt("value")) {
                    is String -> {
                        URL(opt)
                    }

                    is JSONObject -> {
                        URL(opt.optString("href"))
                    }

                    else -> {
                        LOGGER.error { "Invalid Outbound Interaction URL: $js" }
                        null
                    }
                }
            }

        override suspend fun invokeInternal(args: URL?): ApiResult =
            try {
                LOGGER.verbose { "Send Interaction For Outbound Link:\n $args" }
                args?.sendInteractionForOutboundLink(true)
                ApiResult.NullApiResult
            } catch (e: Exception) {
                LOGGER.error(e) { "Send Interaction For Outbound Link Failed." }
                ApiResult.ErrorApiResult(e)
            }
    }

    object SendProperties : ApiBridge<MXOInteractionRequest>() {
        override fun adaptJson(jsObject: JSONObject?): MXOInteractionRequest? = jsObject.toMxoRequest()

        override suspend fun invokeInternal(args: MXOInteractionRequest?): ApiResult =
            try {
                LOGGER.verbose { "Send MXO Properties:\n $args" }
                val interactionResponse =
                    args?.let {
                        mxoSendPropertiesWrapper(true, args)
                    }
                LOGGER.verbose { "MXO Properties Response:\n $interactionResponse" }
                ApiResult.JSONObjectApiResult(interactionResponse.toJson())
            } catch (e: Exception) {
                LOGGER.error(e) { "Send MXO Properties Failed." }
                ApiResult.ErrorApiResult(e)
            }
    }

    object ProcessResponse : ApiBridge<MXOInteractionResponse>() {
        override fun adaptJson(jsObject: JSONObject?): MXOInteractionResponse? =
            jsObject?.let { js ->
                hybridHydrateResponseFromJson(
                    interaction = js.getString(JSON_KEY_INTERACTION),
                    tid = js.getString(JSON_KEY_TID),
                    brandInteractionData = js.getString(JSON_KEY_BRAND_INTERACTION_DATA),
                    customerInteractionData = js.getString(JSON_KEY_CUSTOMER_INTERACTION_DATA),
                )
            }

        override suspend fun invokeInternal(args: MXOInteractionResponse?): ApiResult =
            try {
                LOGGER.verbose { "Process Response:\n $args" }
                args?.process(true)
                ApiResult.NullApiResult
            } catch (e: Exception) {
                LOGGER.error(e) { "Process Response Failed." }
                ApiResult.ErrorApiResult(e)
            }
    }

    object SendInteractionResponseCode : ApiBridge<MXOResponseCodeRequest>() {
        override fun adaptJson(jsObject: JSONObject?): MXOResponseCodeRequest? =
            jsObject?.let { js ->
                mxoResponseCodeRequest {
                    if (js.has(JSON_KEY_INTERACTION)) {
                        interaction = MXOInteraction(URI.create(js.getString(JSON_KEY_INTERACTION)))
                    }
                    if (js.has(JSON_KEY_RESPONSE_CODE)) {
                        responseCode = MXOResponseCode(js.getString(JSON_KEY_RESPONSE_CODE).toString())
                    }
                }
            }

        override suspend fun invokeInternal(args: MXOResponseCodeRequest?): ApiResult =
            try {
                LOGGER.verbose { "Send Interaction Response Code:\n $args" }
                val interactionResponse =
                    args?.let {
                        mxoSendInteractionResponseCodeWrapper(true, it)
                    }
                LOGGER.verbose { "Send Interaction Response Code Response:\n $interactionResponse" }
                ApiResult.JSONObjectApiResult(interactionResponse.toJson())
            } catch (e: Exception) {
                LOGGER.error(e) { "Send Interaction Response Code Failed." }
                ApiResult.ErrorApiResult(e)
            }
    }
}
