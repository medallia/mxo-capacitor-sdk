/* 
 *  Copyright (c) 2024 Medallia. Use subject to licensing terms. 
 */
package com.medallia.mxo.capacitorjs

import android.annotation.TargetApi
import android.os.Build
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import com.medallia.mxo.AutomaticInteractionTrackingConfigurationBridge
import com.medallia.mxo.BridgeCall
import com.medallia.mxo.ConfigurationBridge
import com.medallia.mxo.IdentityTransferConfigurationBridge
import com.medallia.mxo.InteractionBridge
import com.medallia.mxo.LOGGER
import com.medallia.mxo.LoggingBridge
import com.medallia.mxo.OptOutConfigurationBridge
import com.medallia.mxo.ProcessLocationBridge
import com.medallia.mxo.TidBridge
import com.medallia.mxo.automatic.mxoAutomaticInteractionTrackingConfiguration
import com.medallia.mxo.bridgeCall
import com.medallia.mxo.internal.InternalApiProvider
import com.medallia.mxo.internal.telemetry.TelemetryApi
import com.medallia.mxo.jsonError
import com.medallia.mxo.logging.MXOLogComponent
import com.medallia.mxo.logging.MXOLogLevel
import com.medallia.mxo.logging.mxoLoggingConfiguration
import com.medallia.mxo.mxoAutomaticInteractionTrackingConfiguration
import com.medallia.mxo.mxoLoggingConfiguration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject
import kotlin.coroutines.CoroutineContext

@Suppress("TooManyFunctions", "TooGenericExceptionCaught")
@CapacitorPlugin(name = "MedalliaMXO")
@TargetApi(Build.VERSION_CODES.Q)
public class MedalliaMXOPlugin
    @JvmOverloads
    constructor(
        coroutineContext: CoroutineContext = Dispatchers.Default,
    ) : Plugin() {
        private val scope = CoroutineScope(coroutineContext)

        override fun load() {
            super.load()
            try {
                mxoLoggingConfiguration =
                    mxoLoggingConfiguration {
                        levels = setOf(MXOLogLevel.DEBUG)
                        components = setOf(MXOLogComponent.ANY)
                    }
                LOGGER.debug {
                    "MXO CapacitorJS SDK does not support Automatic Interaction Tracking. Disabling."
                }
                mxoAutomaticInteractionTrackingConfiguration =
                    mxoAutomaticInteractionTrackingConfiguration {
                        disableInteractionTracking = true
                        disableWebViewInteractionTracking = true
                    }
            } catch (e: Exception) {
                LOGGER.error(e)
            } finally {
                mxoLoggingConfiguration = mxoLoggingConfiguration { }
            }

            try {
                InternalApiProvider.getTelemetryApi()?.updateFramework(
                    TelemetryApi.TelemetryData(
                        name = "capacitor",
                        // The medallia capacitor plugin will add this to the outgoing build.gradle file
                        // used in the plugin.
                        version = BuildConfig.CAPACITOR_VERSION,
                        sdkVersion = BuildConfig.MXO_CAPACITOR_VERSION,
                    ),
                )
            } catch (e: Exception) {
                LOGGER.error(e)
            }
        }

        private fun getBridgeCall(pluginCall: PluginCall): BridgeCall =
            bridgeCall(
                jsonArgument =
                    pluginCall.data?.let { data ->
                        JSONObject(data.toString())
                    },
                methodName = pluginCall.methodName,
                onResolve = { result ->
                    pluginCall.resolve(JSObject.fromJSONObject(result))
                },
                onReject = { msg, jsonError ->
                    pluginCall.reject(msg, "0", JSObject.fromJSONObject(jsonError))
                },
            )

        @PluginMethod(returnType = PluginMethod.RETURN_PROMISE)
        public fun getConfiguration(pluginCall: PluginCall) {
            scope.launch {
                try {
                    ConfigurationBridge.Getter.invoke(getBridgeCall(pluginCall))
                } catch (exception: Exception) {
                    handleException(exception, pluginCall)
                }
            }
        }

        @PluginMethod(returnType = PluginMethod.RETURN_PROMISE)
        public fun setConfiguration(pluginCall: PluginCall) {
            scope.launch {
                try {
                    ConfigurationBridge.Setter.invoke(getBridgeCall(pluginCall))
                } catch (exception: Exception) {
                    handleException(exception, pluginCall)
                }
            }
        }

        @PluginMethod(returnType = PluginMethod.RETURN_PROMISE)
        public fun getLoggingConfiguration(pluginCall: PluginCall) {
            scope.launch {
                try {
                    LoggingBridge.Getter.invoke(getBridgeCall(pluginCall))
                } catch (exception: Exception) {
                    handleException(exception, pluginCall)
                }
            }
        }

        @PluginMethod(returnType = PluginMethod.RETURN_PROMISE)
        public fun setLoggingConfiguration(pluginCall: PluginCall) {
            scope.launch {
                try {
                    LoggingBridge.Setter.invoke(getBridgeCall(pluginCall))
                } catch (exception: Exception) {
                    handleException(exception, pluginCall)
                }
            }
        }

        @PluginMethod(returnType = PluginMethod.RETURN_PROMISE)
        public fun getAutomaticInteractionTrackingConfiguration(pluginCall: PluginCall) {
            scope.launch {
                try {
                    AutomaticInteractionTrackingConfigurationBridge.Getter.invoke(getBridgeCall(pluginCall))
                } catch (exception: Exception) {
                    handleException(exception, pluginCall)
                }
            }
        }

        @PluginMethod(returnType = PluginMethod.RETURN_PROMISE)
        public fun setAutomaticInteractionTrackingConfiguration(pluginCall: PluginCall) {
            scope.launch {
                try {
                    AutomaticInteractionTrackingConfigurationBridge.Setter
                        .invoke(getBridgeCall(pluginCall))
                } catch (exception: Exception) {
                    handleException(exception, pluginCall)
                }
            }
        }

        @PluginMethod(returnType = PluginMethod.RETURN_PROMISE)
        public fun getOptOutConfiguration(pluginCall: PluginCall) {
            scope.launch {
                try {
                    OptOutConfigurationBridge.Getter.invoke(getBridgeCall(pluginCall))
                } catch (exception: Exception) {
                    handleException(exception, pluginCall)
                }
            }
        }

        @PluginMethod(returnType = PluginMethod.RETURN_PROMISE)
        public fun setOptOutConfiguration(pluginCall: PluginCall) {
            scope.launch {
                try {
                    OptOutConfigurationBridge.Setter.invoke(getBridgeCall(pluginCall))
                } catch (exception: Exception) {
                    handleException(exception, pluginCall)
                }
            }
        }

        @PluginMethod(returnType = PluginMethod.RETURN_PROMISE)
        public fun getIdentityTransferConfiguration(pluginCall: PluginCall) {
            scope.launch {
                try {
                    IdentityTransferConfigurationBridge.Getter.invoke(getBridgeCall(pluginCall))
                } catch (exception: Exception) {
                    handleException(exception, pluginCall)
                }
            }
        }

        @PluginMethod(returnType = PluginMethod.RETURN_PROMISE)
        public fun setIdentityTransferConfiguration(pluginCall: PluginCall) {
            scope.launch {
                try {
                    IdentityTransferConfigurationBridge.Setter.invoke(getBridgeCall(pluginCall))
                } catch (exception: Exception) {
                    handleException(exception, pluginCall)
                }
            }
        }

        @PluginMethod(returnType = PluginMethod.RETURN_PROMISE)
        public fun generateIdentityTransferUrl(pluginCall: PluginCall) {
            scope.launch {
                try {
                    IdentityTransferConfigurationBridge.GenerateIdentityTransferUrl.invoke(getBridgeCall(pluginCall))
                } catch (exception: Exception) {
                    handleException(exception, pluginCall)
                }
            }
        }

        @PluginMethod(returnType = PluginMethod.RETURN_PROMISE)
        public fun getVersion(pluginCall: PluginCall) {
            scope.launch {
                try {
                    VersionBridge.invoke(getBridgeCall(pluginCall))
                } catch (exception: Exception) {
                    handleException(exception, pluginCall)
                }
            }
        }

        @PluginMethod(returnType = PluginMethod.RETURN_PROMISE)
        public fun getTid(pluginCall: PluginCall) {
            scope.launch {
                try {
                    TidBridge.Getter.invoke(getBridgeCall(pluginCall))
                } catch (exception: Exception) {
                    handleException(exception, pluginCall)
                }
            }
        }

        @PluginMethod(returnType = PluginMethod.RETURN_PROMISE)
        public fun clearTid(pluginCall: PluginCall) {
            scope.launch {
                try {
                    TidBridge.Clear.invoke(getBridgeCall(pluginCall))
                } catch (exception: Exception) {
                    handleException(exception, pluginCall)
                }
            }
        }

        @PluginMethod(returnType = PluginMethod.RETURN_PROMISE)
        public fun processLocation(pluginCall: PluginCall) {
            scope.launch {
                try {
                    ProcessLocationBridge.Process.invoke(getBridgeCall(pluginCall))
                } catch (exception: Exception) {
                    handleException(exception, pluginCall)
                }
            }
        }

        @PluginMethod(returnType = PluginMethod.RETURN_PROMISE)
        public fun sendInteraction(pluginCall: PluginCall) {
            scope.launch {
                try {
                    InteractionBridge.SendInteraction.invoke(getBridgeCall(pluginCall))
                } catch (exception: Exception) {
                    handleException(exception, pluginCall)
                }
            }
        }

        @PluginMethod(returnType = PluginMethod.RETURN_PROMISE)
        public fun sendProperties(pluginCall: PluginCall) {
            scope.launch {
                try {
                    InteractionBridge.SendProperties.invoke(getBridgeCall(pluginCall))
                } catch (exception: Exception) {
                    handleException(exception, pluginCall)
                }
            }
        }

        @PluginMethod(returnType = PluginMethod.RETURN_PROMISE)
        public fun sendInteractionResponseCode(pluginCall: PluginCall) {
            scope.launch {
                try {
                    InteractionBridge.SendInteractionResponseCode.invoke(getBridgeCall(pluginCall))
                } catch (exception: Exception) {
                    handleException(exception, pluginCall)
                }
            }
        }

        @PluginMethod(returnType = PluginMethod.RETURN_PROMISE)
        public fun sendInteractionForOutboundLink(pluginCall: PluginCall) {
            scope.launch {
                try {
                    InteractionBridge.SendInteractionForOutboundLink.invoke(getBridgeCall(pluginCall))
                } catch (exception: Exception) {
                    handleException(exception, pluginCall)
                }
            }
        }

        @PluginMethod(returnType = PluginMethod.RETURN_PROMISE)
        public fun processResponse(pluginCall: PluginCall) {
            scope.launch {
                try {
                    InteractionBridge.ProcessResponse.invoke(getBridgeCall(pluginCall))
                } catch (exception: Exception) {
                    handleException(exception, pluginCall)
                }
            }
        }

        @PluginMethod(returnType = PluginMethod.RETURN_PROMISE)
        public fun processDeeplink(pluginCall: PluginCall) {
            scope.launch {
                try {
                    IdentityTransferConfigurationBridge.ProcessDeeplink.invoke(getBridgeCall(pluginCall))
                } catch (exception: Exception) {
                    handleException(exception, pluginCall)
                }
            }
        }

        private fun handleException(
            exception: Exception,
            pluginCall: PluginCall,
        ) {
            LOGGER.error(exception) {
                "${pluginCall.methodName} Failed."
            }
            val jsonError =
                jsonError {
                    message = exception.message
                    apiName = pluginCall.methodName
                    cause = exception.cause?.message
                }
            pluginCall.reject("${pluginCall.methodName} Failed.", exception, JSObject(jsonError.toString()))
        }
    }
