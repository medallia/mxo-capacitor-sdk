/* 
 *  Copyright (c) 2024 Medallia. Use subject to licensing terms. 
 */
package com.medallia.mxo

import org.json.JSONObject

internal class JsonErrorBuilder {
    var message: String? = null
    var apiName: String? = null
    var cause: String? = null

    fun build(): JSONObject =
        JSONObject().apply {
            put("message", message)
            put("apiName", apiName)
            put("cause", cause)
        }
}

internal fun jsonError(block: JsonErrorBuilder.() -> Unit): JSONObject = JsonErrorBuilder().apply(block).build()
