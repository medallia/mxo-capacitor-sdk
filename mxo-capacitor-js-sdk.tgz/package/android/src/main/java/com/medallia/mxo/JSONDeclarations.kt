/* 
 *  Copyright (c) 2024 Medallia. Use subject to licensing terms. 
 */
package com.medallia.mxo

import org.json.JSONArray

internal inline fun <reified T> JSONArray.mapNotNull(transform: (Any?) -> T?): List<T> {
    val result = mutableListOf<T>()
    for (i in 0 until this.length()) {
        transform(opt(i))?.let { result.add(it) }
    }
    return result
}

internal inline fun <reified T> JSONArray.map(transform: (Any?) -> T?): List<T?> {
    val result = mutableListOf<T?>()
    for (i in 0 until this.length()) {
        result.add(transform(opt(i)))
    }
    return result
}

internal fun JSONArray?.orEmpty(): JSONArray = this ?: JSONArray()
