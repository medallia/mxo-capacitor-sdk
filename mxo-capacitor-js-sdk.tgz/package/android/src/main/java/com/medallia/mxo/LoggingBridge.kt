/* 
 *  Copyright (c) 2024 Medallia. Use subject to licensing terms. 
 */
package com.medallia.mxo

import android.annotation.SuppressLint
import com.medallia.mxo.logging.MXOLogComponent
import com.medallia.mxo.logging.MXOLogLevel
import com.medallia.mxo.logging.MXOLoggingConfiguration
import org.json.JSONArray
import org.json.JSONObject

@Suppress("TooGenericExceptionCaught")
@SuppressLint("NewApi")
internal object LoggingBridge {
    private const val JSON_KEY_LEVELS = "levels"
    private const val JSON_KEY_COMPONENTS = "components"

    object Setter : ApiBridge<MXOLoggingConfiguration>() {
        override fun adaptJson(jsObject: JSONObject?): MXOLoggingConfiguration? =
            jsObject?.let { js ->
                (mxoLoggingConfiguration?.builder() ?: MXOLoggingConfiguration.Builder())
                    .apply {
                        if (js.has(JSON_KEY_LEVELS)) {
                            levels =
                                js
                                    .optJSONArray(JSON_KEY_LEVELS)
                                    .orEmpty()
                                    .mapNotNull {
                                        when (it) {
                                            is String -> {
                                                try {
                                                    MXOLogLevel.valueOf(it)
                                                } catch (_: Exception) {
                                                    null
                                                }
                                            }

                                            else -> {
                                                null
                                            }
                                        }
                                    }.toSet()
                        }

                        if (js.has(JSON_KEY_COMPONENTS)) {
                            components =
                                js
                                    .optJSONArray(JSON_KEY_COMPONENTS)
                                    .orEmpty()
                                    .mapNotNull {
                                        when (it) {
                                            is String -> {
                                                try {
                                                    MXOLogComponent.valueOf(it)
                                                } catch (_: Exception) {
                                                    null
                                                }
                                            }

                                            else -> {
                                                null
                                            }
                                        }
                                    }.toSet()
                        }
                    }.build()
            }

        override suspend fun invokeInternal(args: MXOLoggingConfiguration?): ApiResult =
            try {
                mxoLoggingConfiguration = args
                LOGGER.verbose { "Set MXO Logging Configuration:\n $args" }
                ApiResult.NullApiResult
            } catch (e: Exception) {
                LOGGER.error(e) { "Set MXO Logging Configuration Failed." }
                ApiResult.ErrorApiResult(e)
            }
    }

    object Getter : ApiBridge<Unit>() {
        override fun adaptJson(jsObject: JSONObject?): Unit? = null

        override suspend fun invokeInternal(args: Unit?): ApiResult =
            try {
                val js =
                    mxoLoggingConfiguration?.let { config ->
                        val levels =
                            config.levels
                                .fold(JSONArray()) { result, item -> result.apply { put(item.name) } }

                        val components =
                            config.components
                                .fold(JSONArray()) { result, item -> result.apply { put(item.name) } }

                        JSONObject().apply {
                            put(JSON_KEY_COMPONENTS, components)
                            put(JSON_KEY_LEVELS, levels)
                        }
                    }
                LOGGER.verbose { "Get MXO Logging Configuration:\n $js" }
                ApiResult.JSONObjectApiResult(js)
            } catch (e: Exception) {
                LOGGER.error(e) { "Get MXO Logging Configuration Failed." }
                ApiResult.ErrorApiResult(e)
            }
    }
}
