/* 
 *  Copyright (c) 2024 Medallia. Use subject to licensing terms. 
 */
package com.medallia.mxo.capacitorjs

import android.annotation.TargetApi
import android.os.Build
import com.medallia.mxo.ApiBridge
import com.medallia.mxo.LOGGER
import com.medallia.mxo.mxoVersion
import org.json.JSONObject

@TargetApi(Build.VERSION_CODES.P)
@Suppress("TooGenericExceptionCaught")
internal object VersionBridge : ApiBridge<Unit>() {
    override fun adaptJson(jsObject: JSONObject?): Unit? = null

    override suspend fun invokeInternal(args: Unit?): ApiResult =
        try {
            val version = "$mxoVersion-${BuildConfig.MXO_CAPACITOR_VERSION}"
            LOGGER.verbose { "Get Version: $version" }
            ApiResult.StringApiResult(version)
        } catch (e: Exception) {
            LOGGER.error(e) { "Get MXO Version Failed." }
            ApiResult.ErrorApiResult(e)
        }
}
