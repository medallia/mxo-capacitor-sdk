/* 
 *  Copyright (c) 2024 Medallia. Use subject to licensing terms. 
 */
package com.medallia.mxo

import org.json.JSONObject

internal fun mxoResult(string: String?): JSONObject =
    JSONObject().apply {
        putOpt("value", string)
    }

internal fun mxoResult(obj: JSONObject?): JSONObject =
    JSONObject().apply {
        putOpt("value", obj)
    }
