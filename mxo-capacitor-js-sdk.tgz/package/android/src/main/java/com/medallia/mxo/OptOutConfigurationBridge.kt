/* 
 *  Copyright (c) 2024 Medallia. Use subject to licensing terms. 
 */
package com.medallia.mxo

import android.annotation.SuppressLint
import com.medallia.mxo.optout.MXOOptInOptions
import com.medallia.mxo.optout.MXOOptOutConfiguration
import org.json.JSONArray
import org.json.JSONObject

@Suppress("TooGenericExceptionCaught")
@SuppressLint("NewApi")
internal object OptOutConfigurationBridge {
    private const val JSON_KEY_OPT_OUT = "optOut"
    private const val JSON_KEY_OPT_IN_OPTIONS = "optInOptions"

    object Setter : ApiBridge<MXOOptOutConfiguration>() {
        override fun adaptJson(jsObject: JSONObject?): MXOOptOutConfiguration? =
            jsObject?.let { js ->
                (mxoOptOutConfiguration?.builder() ?: MXOOptOutConfiguration.Builder())
                    .apply {
                        if (js.has(JSON_KEY_OPT_OUT)) {
                            optOut = js.getBoolean(JSON_KEY_OPT_OUT)
                        }
                        if (js.has(JSON_KEY_OPT_IN_OPTIONS)) {
                            optInOptions =
                                js
                                    .getJSONArray(JSON_KEY_OPT_IN_OPTIONS)
                                    .orEmpty()
                                    .mapNotNull {
                                        when (it) {
                                            is String -> {
                                                try {
                                                    MXOOptInOptions.valueOf(it)
                                                } catch (_: Exception) {
                                                    null
                                                }
                                            }

                                            else -> {
                                                null
                                            }
                                        }
                                    }.toSet()
                        }
                    }.build()
            }

        override suspend fun invokeInternal(args: MXOOptOutConfiguration?): ApiResult =
            try {
                mxoOptOutConfiguration = args
                LOGGER.verbose { "Set MXO OptOut Configuration:\n $args" }
                ApiResult.NullApiResult
            } catch (e: Exception) {
                LOGGER.error(e) { "Set MXO OptOut Configuration Failed." }
                ApiResult.ErrorApiResult(e)
            }
    }

    object Getter : ApiBridge<Unit>() {
        override fun adaptJson(jsObject: JSONObject?): Unit? = null

        override suspend fun invokeInternal(args: Unit?): ApiResult =
            try {
                val js =
                    mxoOptOutConfiguration?.let { config ->
                        JSONObject().apply {
                            put(JSON_KEY_OPT_OUT, config.optOut)
                            put(
                                JSON_KEY_OPT_IN_OPTIONS,
                                config.optInOptions
                                    .fold(JSONArray()) { result, item -> result.apply { put(item.name) } },
                            )
                        }
                    }
                LOGGER.verbose { "Get MXO OptOut Configuration:\n $js" }
                ApiResult.JSONObjectApiResult(js)
            } catch (e: Exception) {
                LOGGER.error(e) { "Get MXO OptOut Configuration Failed." }
                ApiResult.ErrorApiResult(e)
            }
    }
}
