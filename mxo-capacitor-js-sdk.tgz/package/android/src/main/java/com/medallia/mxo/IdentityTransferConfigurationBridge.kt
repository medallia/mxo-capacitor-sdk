/* 
 *  Copyright (c) 2024 Medallia. Use subject to licensing terms. 
 */
package com.medallia.mxo

import android.annotation.SuppressLint
import com.medallia.mxo.identitytransfer.MXOIdentityTransferConfiguration
import com.medallia.mxo.identitytransfer.MXOIdentityTransferUriMatcher
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI
import java.net.URL

@Suppress("TooGenericExceptionCaught")
@SuppressLint("NewApi")
internal object IdentityTransferConfigurationBridge {
    private const val JSON_KEY_DISABLE_IDENTITY_TRANSFER = "disableIdentityTransfer"
    private const val JSON_KEY_EXCLUDE_LIST = "excludeList"
    private const val JSON_KEY_INCLUDE_LIST = "includeList"

    private fun Any?.maybeValue(): String? =
        when (this) {
            is String -> this
            is JSONObject -> this.optString("value")
            else -> null
        }

    private fun MXOIdentityTransferUriMatcher.toJson(): JSONObject =
        JSONObject().apply {
            when (this@toJson) {
                is MXOIdentityTransferUriMatcher.ExactMatch -> put("value", value.toString())
                is MXOIdentityTransferUriMatcher.RegexMatch -> put("value", value.toString())
            }
        }

    object Setter : ApiBridge<MXOIdentityTransferConfiguration>() {
        override fun adaptJson(jsObject: JSONObject?): MXOIdentityTransferConfiguration? =
            jsObject?.let { js ->
                (
                    mxoIdentityTransferConfiguration?.builder()
                        ?: MXOIdentityTransferConfiguration.Builder()
                ).apply {
                    if (js.has(JSON_KEY_DISABLE_IDENTITY_TRANSFER)) {
                        disableIdentityTransfer = js.getBoolean(JSON_KEY_DISABLE_IDENTITY_TRANSFER)
                    }
                    if (js.has(JSON_KEY_EXCLUDE_LIST)) {
                        excludeList =
                            js
                                .getJSONArray(JSON_KEY_EXCLUDE_LIST)
                                .orEmpty()
                                .map { it.maybeValue() }
                                .filterNot { it.isNullOrEmpty() }
                                .map { MXOIdentityTransferUriMatcher.ExactMatch(URI(it)) }
                                .toSet()
                    }
                    if (js.has(JSON_KEY_INCLUDE_LIST)) {
                        includeList =
                            js
                                .getJSONArray(JSON_KEY_INCLUDE_LIST)
                                .orEmpty()
                                .map { it.maybeValue() }
                                .filterNot { it.isNullOrEmpty() }
                                .map { MXOIdentityTransferUriMatcher.ExactMatch(URI(it)) }
                                .toSet()
                    }
                }.build()
            }

        override suspend fun invokeInternal(args: MXOIdentityTransferConfiguration?): ApiResult =
            try {
                mxoIdentityTransferConfiguration = args
                LOGGER.verbose { "Set MXO Identity Transfer Configuration:\n $args" }
                ApiResult.NullApiResult
            } catch (e: Exception) {
                LOGGER.error(e) { "Set MXO Identity Transfer Configuration Failed." }
                ApiResult.ErrorApiResult(e)
            }
    }

    object Getter : ApiBridge<Unit>() {
        override fun adaptJson(jsObject: JSONObject?): Unit? = null

        override suspend fun invokeInternal(args: Unit?): ApiResult =
            try {
                val js =
                    mxoIdentityTransferConfiguration?.let { config ->
                        JSONObject().apply {
                            put(JSON_KEY_DISABLE_IDENTITY_TRANSFER, config.disableIdentityTransfer)
                            put(
                                JSON_KEY_EXCLUDE_LIST,
                                config.excludeList
                                    .orEmpty()
                                    .fold(JSONArray()) { result, item -> result.apply { put(item.toJson()) } },
                            )
                            put(
                                JSON_KEY_INCLUDE_LIST,
                                config.includeList
                                    .orEmpty()
                                    .fold(JSONArray()) { result, item -> result.apply { put(item.toJson()) } },
                            )
                        }
                    }
                LOGGER.verbose { "Get MXO Identity Transfer Configuration:\n $js" }
                ApiResult.JSONObjectApiResult(js)
            } catch (e: Exception) {
                LOGGER.error(e) { "Get MXO Identity Transfer Configuration Failed." }
                ApiResult.ErrorApiResult(e)
            }
    }

    object GenerateIdentityTransferUrl : ApiBridge<URL>() {
        override fun adaptJson(jsObject: JSONObject?): URL? =
            jsObject?.let { js ->
                when (val opt = js.opt("value")) {
                    is String -> {
                        URL(opt)
                    }

                    is JSONObject -> {
                        URL(opt.optString("href"))
                    }

                    else -> {
                        LOGGER.error { "Invalid Identity Transfer URL: $js" }
                        null
                    }
                }
            }

        override suspend fun invokeInternal(args: URL?): ApiResult =
            try {
                val urlString = args?.generateIdentityTransferUrl(true)?.toString()
                LOGGER.verbose { "Generate MXO Identity Transfer URL:\n $urlString" }
                ApiResult.StringApiResult(urlString)
            } catch (e: Exception) {
                LOGGER.error(e) { "Generate MXO Identity Transfer URL Failed." }
                ApiResult.ErrorApiResult(e)
            }
    }

    object ProcessDeeplink : ApiBridge<URI>() {
        override fun adaptJson(jsObject: JSONObject?): URI? =
            jsObject?.let { js ->
                when (val opt = js.opt("value")) {
                    is String -> {
                        URI(opt)
                    }

                    is JSONObject -> {
                        URI(opt.optString("href"))
                    }

                    else -> {
                        LOGGER.error { "Invalid Deep Link URI: $js" }
                        null
                    }
                }
            }

        override suspend fun invokeInternal(args: URI?): ApiResult =
            try {
                args?.process(true)
                LOGGER.verbose { "Process DeepLink Done." }
                ApiResult.NullApiResult
            } catch (e: Exception) {
                LOGGER.error(e) { "Process DeepLink URL Failed." }
                ApiResult.ErrorApiResult(e)
            }
    }
}
