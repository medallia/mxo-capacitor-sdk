/* 
 *  Copyright (c) 2024 Medallia. Use subject to licensing terms. 
 */
package com.medallia.mxo

import com.medallia.mxo.internal.InternalApiProvider
import com.medallia.mxo.internal.logging.Logger

internal val LOGGER: Logger by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
    InternalApiProvider.getLogger()
}
