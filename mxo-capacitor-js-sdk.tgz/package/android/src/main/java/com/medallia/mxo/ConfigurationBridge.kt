/* 
 *  Copyright (c) 2024 Medallia. Use subject to licensing terms. 
 */
package com.medallia.mxo

import android.annotation.SuppressLint
import com.medallia.mxo.configuration.MXOConfiguration
import com.medallia.mxo.configuration.MXOMode
import org.json.JSONObject
import java.net.URI

@Suppress("TooGenericExceptionCaught")
@SuppressLint("NewApi")
internal object ConfigurationBridge {
    private const val JSON_KEY_HOST = "host"
    private const val JSON_KEY_SITEKEY = "siteKey"
    private const val JSON_KEY_TOUCHPOINT = "touchpoint"
    private const val JSON_KEY_MODE = "mode"

    object Setter : ApiBridge<MXOConfiguration>() {
        @Suppress("NestedBlockDepth")
        override fun adaptJson(jsObject: JSONObject?): MXOConfiguration? =
            jsObject?.let { js ->
                (mxoConfiguration?.builder() ?: MXOConfiguration.Builder())
                    .apply {
                        if (js.has(JSON_KEY_HOST)) {
                            host = URI(js.getString(JSON_KEY_HOST))
                        }
                        if (js.has(JSON_KEY_SITEKEY)) {
                            siteKey = js.getString(JSON_KEY_SITEKEY)
                        }
                        if (js.has(JSON_KEY_TOUCHPOINT)) {
                            touchpoint = URI(js.getString(JSON_KEY_TOUCHPOINT))
                        }
                        if (js.has(JSON_KEY_MODE)) {
                            mode = if (js.getInt(JSON_KEY_MODE) == 1) MXOMode.ADMIN else MXOMode.USER
                        }
                    }.build()
            }

        override suspend fun invokeInternal(args: MXOConfiguration?): ApiResult =
            try {
                mxoConfiguration = args
                LOGGER.verbose { "Set MXO Configuration:\n $args" }
                ApiResult.NullApiResult
            } catch (e: Exception) {
                LOGGER.error(e) { "Set MXO Configuration Failed." }
                ApiResult.ErrorApiResult(e)
            }
    }

    object Getter : ApiBridge<Unit>() {
        override fun adaptJson(jsObject: JSONObject?): Unit? = null

        override suspend fun invokeInternal(args: Unit?): ApiResult =
            try {
                val js =
                    mxoConfiguration?.let { config ->
                        JSONObject().apply {
                            put(JSON_KEY_HOST, config.host?.toString())
                            put(JSON_KEY_MODE, if (config.mode == MXOMode.ADMIN) 1 else 0)
                            put(JSON_KEY_TOUCHPOINT, config.touchpoint?.toString())
                            put(JSON_KEY_SITEKEY, config.siteKey)
                        }
                    }
                LOGGER.verbose { "Get MXO Configuration:\n $js" }
                ApiResult.JSONObjectApiResult(js)
            } catch (e: Exception) {
                LOGGER.error(e) { "Get MXO Configuration Failed." }
                ApiResult.ErrorApiResult(e)
            }
    }
}
