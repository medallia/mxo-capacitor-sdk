Pod::Spec.new do |spec|
    spec.name = 'MedalliaMxoCapacitorJsSdk'
    spec.version = '4.0.3'
    spec.summary = 'A Medallia Mobile SDK Capacitor plugin.'
    spec.homepage = 'https://www.medallia.com'
    spec.license = 'Copyright © 2025 Medallia. Use subject to licensing terms.'
    spec.author = 'cocoapods-mxo@medallia.com'
    spec.source = {
        :git => 'https://github.com/medallia/mxo-capacitor-js-sdk.git',
        :tag => '4.0.3',
    }
    spec.ios.deployment_target = '15.0'
    spec.source_files = ['ios/**/*.{swift,h,m,c,cc,mm,cpp}']
    spec.static_framework = true
    spec.dependency 'Capacitor'
    spec.dependency 'medallia-mxo-ios-sdk', '4.0.0'
end
