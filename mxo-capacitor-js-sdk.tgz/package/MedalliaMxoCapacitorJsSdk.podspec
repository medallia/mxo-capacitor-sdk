# Copyright © 2025 Medallia. Use subject to licensing terms.
#
# Capacitor normalizes plugin pod names; keep this file name in sync.
# https://github.com/ionic-team/capacitor/blob/f957243abe46618afa0998f53d70cf6459c08d0e/cli/src/plugin.ts#L123

Pod::Spec.new do |s|
  s.name = 'MedalliaMxoCapacitorJsSdk'
  s.version = '4.1.0'
  s.summary = 'MXO Capacitor SDK for iOS and Android'
  s.license = 'Copyright © 2025 Medallia. Use subject to licensing terms.'
  s.homepage = 'https://medallia.com'
  s.authors = { 'Medallia' => 'cocoapods-mxo@medallia.com' }
  s.source = { :git => 'https://github.com/medallia/mxo-capacitor-sdk', :tag => '4.1.0' }
  s.ios.deployment_target = '15.0'
  s.swift_version = '5.1'
  s.source_files = 'ios/**/*.{swift,h,m,c,cc,mm,cpp}'
  s.dependency 'Capacitor'
  s.dependency 'medallia-mxo-ios-sdk', '4.0.0'
  s.static_framework = true
end