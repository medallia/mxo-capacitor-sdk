// swift-tools-version: 5.9
// Copyright © 2025 Medallia. Use subject to licensing terms.

import PackageDescription

let package = Package(
    name: "MedalliaMxoCapacitorJsSdk",
    platforms: [
        .iOS(.v15)
    ],
    products: [
        .library(
            name: "MedalliaMxoCapacitorJsSdk",
            targets: ["MedalliaMXOPlugin"]
        )
    ],
    dependencies: [
        .package(url: "https://github.com/ionic-team/capacitor-swift-pm.git", from: "7.0.0"),
        .package(
            url: "https://github.com/medallia/mxo-ios-sdk",
            .upToNextMajor(from: "4.0.0")
        )
    ],
    targets: [
        .target(
            name: "MedalliaMXOPlugin",
            dependencies: [
                .product(name: "Capacitor", package: "capacitor-swift-pm"),
                .product(name: "Cordova", package: "capacitor-swift-pm"),
                .product(name: "medallia-mxo-ios-sdk", package: "mxo-ios-sdk")
            ],
            path: "ios"
        )
    ]
)