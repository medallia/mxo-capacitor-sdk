import Foundation
import MedalliaMXO

public class TidBridge {
    public static let getter: any ApiBridge = Getter()
    public static let clear: any ApiBridge = Clear()
    
    private init() { }
    
    private class Getter : ApiBridge {
        typealias ARGS = Any
        
        private let logger = ServiceLocator.shared.getLogger()
        
        func invokeInternal(args: ARGS?) async -> ApiResult {
            do {
                let mxoNative = ServiceLocator.shared.getMXONative()
                let tid = try mxoNative.getTid()
                logger.debug(e: nil) {
                    return "TID: \(tid)"
                }
                return ApiResult.StringApiResult(tid)
            } catch {
                logger.error(e: error, msg: nil)
                return ApiResult.ErrorApiResult(
                    ApiResult.Error(
                        message: "Error getting MXO TID.",
                        apiName: "TidBridge.Getter",
                        cause: error.localizedDescription
                    ))
            }
        }
        
        func adaptJson(jsObject: Dictionary<String, Any>?) -> ARGS? {
            // ignored since its a getter
            return nil
        }
    }
    
    private class Clear : ApiBridge {
        typealias ARGS = Any
        
        private let logger = ServiceLocator.shared.getLogger()
        
        func invokeInternal(args: ARGS?) async -> ApiResult {
            do {
                let mxoNative = ServiceLocator.shared.getMXONative()
                try mxoNative.clearTid()
                logger.debug(e: nil) {
                    return "TID cleared."
                }
                return ApiResult.NullApiResult
            } catch {
                logger.error(e: error, msg: nil)
                return ApiResult.ErrorApiResult(
                    ApiResult.Error(
                        message: "Error clearing MXO TID.",
                        apiName: "TidBridge.Clear",
                        cause: error.localizedDescription
                    ))
            }
        }
        
        func adaptJson(jsObject: Dictionary<String, Any>?) -> ARGS? {
            // ignored since its a void
            return nil
        }
    }
}
