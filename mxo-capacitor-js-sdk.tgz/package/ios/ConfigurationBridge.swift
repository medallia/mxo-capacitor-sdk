import Foundation
import MedalliaMXO

struct ConfigurationDeclarations {
    static let keySitekey = "siteKey"
    static let keyTouchpoint = "touchpoint"
    static let keyHost = "host"
    static let keyMode = "mode"
}

extension Dictionary<String, Any> {
    func toMxoConfiguration() -> MXOConfiguration {
        let builder = (try? ServiceLocator.shared.getMXONative().getConfiguration()?.builder()) ?? MXOConfigurationBuilder()
        
        if let sitekey = (self[ConfigurationDeclarations.keySitekey] as? String) {
            builder.siteKey = sitekey
        }
        
        if let touchpoint = (self[ConfigurationDeclarations.keyTouchpoint] as? String) {
            builder.touchpoint = URL(string: touchpoint)
        }

        if let host = (self[ConfigurationDeclarations.keyHost] as? String) {
            builder.host = URL(string: host)
        }
        
        if let mode = (self[ConfigurationDeclarations.keyMode] as? Int) {
            builder.adminMode = mode == 1
        }
        
        return builder.build()
    }
}

extension MXOConfiguration {
    func toJs() -> [String:Any?] {
        var result: [String:Any?] = [:]
        result[ConfigurationDeclarations.keyMode] = (self.adminMode) ? 1 : 0
        result[ConfigurationDeclarations.keyHost] = self.host?.absoluteString
        result[ConfigurationDeclarations.keySitekey] = self.siteKey
        result[ConfigurationDeclarations.keyTouchpoint] = self.touchpoint?.absoluteString
        return result
    }
}

public class ConfigurationBridge {
    public static let setter: any ApiBridge = Setter()
    public static let getter: any ApiBridge = Getter()
    
    private init () { }
    
    private class Setter : ApiBridge {
        private let logger = ServiceLocator.shared.getLogger()
        
        func invokeInternal(args: MXOConfiguration?) async -> ApiResult {
            do {
                let mxoNative = ServiceLocator.shared.getMXONative()
                try mxoNative.setConfiguration(config: args)
                logger.debug(e: nil) {
                    let argsString = (args != nil) ? String(describing: args) : "null"
                    return "Set Configuration to: \(argsString)"
                }
                return ApiResult.NullApiResult
            } catch {
                return ApiResult.ErrorApiResult(
                    ApiResult.Error(
                        message: "Error setting MXO configuration.",
                        apiName: "ConfigurationBridge.Setter",
                        cause: error.localizedDescription
                    ))
            }
        }
        
        func adaptJson(jsObject: Dictionary<String, Any>?) -> MXOConfiguration? {
            return jsObject?.toMxoConfiguration()
        }
        
        typealias ARGS = MXOConfiguration
    }
    
    private class Getter : ApiBridge {
        private let logger = ServiceLocator.shared.getLogger()
        func invokeInternal(args: Any?) async -> ApiResult {
            do {
                if let current = try ServiceLocator.shared.getMXONative().getConfiguration() {
                    let result = current.toJs()
                    logger.debug(e: nil) {
                        return "Configuration: \(result)"
                    }
                    return ApiResult.JSObjectApiResult(result)
                } else {
                    return ApiResult.NullApiResult
                }
            } catch {
                logger.error(e: error, msg: nil)
                return ApiResult.ErrorApiResult(
                    ApiResult.Error(
                        message: "Error getting MXO configuration.",
                        apiName: "ConfigurationBridge.Getter",
                        cause: error.localizedDescription
                    ))
            }
        }
        
        func adaptJson(jsObject: Dictionary<String, Any>?) -> Any? {
            // ignored for getter
            return nil
        }
        
        typealias ARGS = Any
    }
}
