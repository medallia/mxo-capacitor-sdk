import Foundation

public protocol ApiBridge {
    associatedtype ARGS
    func invokeInternal(args: ARGS?) async -> ApiResult
    func adaptJson(jsObject: Dictionary<String, Any>?) -> ARGS?
}

extension ApiBridge {
    public func invoke(_ call: BridgeCall, _ apiName: String) async -> Void {
        guard let jsObject = call.jsObjectRepresentation else {
            let error = ApiResult.Error(message: "Missing JS Representation", apiName: apiName, cause: "Unknown")
            let apierror = ApiResult.ErrorApiResult(error)
            return call.reject(
                msg: "Missing JS Representation",
                error: nil,
                result: apierror.jsonValue(apiName)
            )
        }
        let args = adaptJson(jsObject: jsObject)
        let result = await invokeInternal(args: args)
        call.resolve(resolved: result.jsonValue(apiName))
    }
}

public enum ApiResult {
    case NullApiResult
    case ErrorApiResult(Error)
    case StringApiResult(String)
    case JSObjectApiResult([String: Any?])

    public struct Error {
        let message: String?
        let apiName: String?
        let cause: String?
    }

    func jsonValue(_ apiName: String) -> [String: Any?] {
        switch self {
        case .NullApiResult:
            return ["value": nil]
        case .ErrorApiResult (let error):
            let json = JsonErrorBuilder()
                .withCause(error.cause)
                .withMessage(error.message)
                .withApiName(error.apiName)
                .build()
            return ["value": json]
        case .StringApiResult (let value):
            return ["value": value]
        case .JSObjectApiResult (let jsObject):
            return ["value": jsObject]
        }
    }
}
