import Foundation
import MedalliaMXO

public class LoggerThunderheadAdapter: Logger {
    public static let shared = LoggerThunderheadAdapter()
    
    private let selectorHybridLog = NSSelectorFromString("hybridLog:message:")
    
    private init() { }
    
    public func debug(e: Error?, msg: (() -> String)?) {
        log(level: MXOLogLevel.debug, e: e, msg: msg)
    }
    
    public func error(e: Error?, msg: (() -> String)?) {
        log(level: MXOLogLevel.error, e: e, msg: msg)
    }
    
    private func log(level: MXOLogLevel, e: Error?, msg: (() -> String)?) {
        if MedalliaMXO.responds(to: selectorHybridLog) {
            var finalMsg = ""
            if let eMsg = e?.localizedDescription {
                finalMsg += eMsg
            }
            if let m = msg {
                finalMsg += " "
                finalMsg += m()
            }
            MedalliaMXO.perform(selectorHybridLog, with: level, with: finalMsg)
        } else {
            print("MedalliaMXO Logger not found.")
        }
    }
}
