import Foundation

public class ServiceLocator {
    public static let shared = ServiceLocator()
    
    /// Used for tests only to mock out calls to MedalliaMXO.
    public var mxoNative: (any MXONative)? = nil
    
    private init() { }
    
    public func getLogger() -> Logger {
        return LoggerThunderheadAdapter.shared
    }
    
    func getMXONative() -> MXONative {
        return mxoNative ?? MXONativeImpl.shared
    }
}

