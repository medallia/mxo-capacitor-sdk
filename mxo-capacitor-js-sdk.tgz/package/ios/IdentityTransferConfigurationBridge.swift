import Foundation
import MedalliaMXO

struct IdentityTransferConfigDeclarations {
    static let disableIdentityTransfer = "disableIdentityTransfer"
    static let includeList = "includeList"
    static let excludeList = "excludeList"
}

extension Dictionary<String, Any> {
    func toMxoIdentityTransferConfiguration() -> MXOIdentityTransferConfiguration {
        let builder = (try? ServiceLocator.shared.getMXONative().getIdentityTransferConfiguration()?.builder()) ?? MXOIdentityTransferConfigurationBuilder()

        if let disable = (self[IdentityTransferConfigDeclarations.disableIdentityTransfer] as? Bool) {
            builder.disableIdentityTransfer = disable
        }

        if let includeList = (self[IdentityTransferConfigDeclarations.includeList] as? Array<Any>) {
            builder.includeList = includeList.toMxoIdentityMatchers()
        }

        if let excludeList = (self[IdentityTransferConfigDeclarations.excludeList] as? Array<Any>) {
            builder.excludeList = excludeList.toMxoIdentityMatchers()
        }

        return builder.build()
    }
}

extension Array<Any> {
    func toMxoIdentityMatchers() -> [MXOIdentityTransferUriMatcher] {
        var matchers = [MXOIdentityTransferUriMatcher]()

        for index in 0..<self.endIndex {
            if let maybeMatcher = (self[index] as? Dictionary<String, Any?>),
               let url = maybeMatcher["value"] as? String,
               let matcher = (try? MXOIdentityTransferUriMatcher(withUrl: URL(string: url))){
                matchers.append(matcher)
            }
        }

        return matchers
    }
}

extension MXOIdentityTransferConfiguration {
    func toJs() -> [String:Any?] {
        var result = [String:Any?]()

        result[IdentityTransferConfigDeclarations.disableIdentityTransfer] = self.disableIdentityTransfer
        result[IdentityTransferConfigDeclarations.includeList] = (self.includeList?.map {
            var value = ""
            if let absoluteString = ($0.value as? URL)?.absoluteString {
                value = absoluteString
            }
            return ["value": value]
        } ?? []) as Array<Any>
        result[IdentityTransferConfigDeclarations.excludeList] = (self.excludeList?.map {
            var value = ""
            if let absoluteString = ($0.value as? URL)?.absoluteString {
                value = absoluteString
            }
            return ["value": value]
        } ?? []) as Array<Any>

        return result
    }
}

public class IdentityTransferConfigurationBridge {
    public static let setter: any ApiBridge = Setter()
    public static let getter: any ApiBridge = Getter()
    public static let processDeeplink: any ApiBridge = ProcessDeeplink()
    public static let generateIdentityTransferUrl: any ApiBridge = GenerateIdentityTransferUrl()

    private init () { }

    private class Setter : ApiBridge {
        private let logger = ServiceLocator.shared.getLogger()

        func invokeInternal(args: MXOIdentityTransferConfiguration?) async -> ApiResult {
            do {
                let mxoNative = ServiceLocator.shared.getMXONative()
                try mxoNative.setIdentityTransferConfiguration(config: args)
                logger.debug(e: nil) {
                    let argsString = args != nil ? String(describing: args) : "null"
                    return "Set MXO Identity Transfer Configuration to: \(argsString)"
                }
                return ApiResult.NullApiResult
            } catch {
                return ApiResult.ErrorApiResult(
                    ApiResult.Error(
                        message: "Error setting MXO Identity Transfer Configuration.",
                        apiName: "IdentityTransferConfigurationBridge.Setter",
                        cause: error.localizedDescription
                    ))
            }
        }

        func adaptJson(jsObject: Dictionary<String, Any>?) -> MXOIdentityTransferConfiguration? {
            return jsObject?.toMxoIdentityTransferConfiguration()
        }

        typealias ARGS = MXOIdentityTransferConfiguration
    }

    private class Getter : ApiBridge {
        private let logger = ServiceLocator.shared.getLogger()
        func invokeInternal(args: Any?) async -> ApiResult {
            do {
                if let current = try ServiceLocator.shared.getMXONative().getIdentityTransferConfiguration() {
                    let result = current.toJs()
                    logger.debug(e: nil) {
                        return "Identity Transfer Configuration: \(result)"
                    }
                    return ApiResult.JSObjectApiResult(result)
                } else {
                    return ApiResult.NullApiResult
                }
            } catch {
                logger.error(e: error, msg: nil)
                return ApiResult.ErrorApiResult(
                    ApiResult.Error(
                        message: "Error getting MXO Identity Transfer Configuration.",
                        apiName: "IdentityTransferConfigurationBridge.Getter",
                        cause: error.localizedDescription
                    ))
            }
        }

        func adaptJson(jsObject: Dictionary<String, Any>?) -> ARGS? {
            // ignored for getter
            return nil
        }

        typealias ARGS = Any
    }


    private class ProcessDeeplink : ApiBridge {
        private let logger = ServiceLocator.shared.getLogger()

        func invokeInternal(args: URL?) async -> ApiResult {
            do {
                if let url = args {
                    let mxoNative = ServiceLocator.shared.getMXONative()

                    try await mxoNative.process(deepLink: url)
                    logger.debug(e: nil) {
                        return "Processed deepLink: \(url)"
                    }
                    return ApiResult.NullApiResult
                } else {
                    return ApiResult.ErrorApiResult(ApiResult.Error(message: "Invalid Deep Link", apiName: "IdentityTransferConfigurationBridge.ProcessDeeplink", cause: nil))
                }
            } catch {
                return ApiResult.ErrorApiResult(
                    ApiResult.Error(
                        message: "Error Processing DeepLink",
                        apiName: "IdentityTransferConfigurationBridge.ProcessDeeplink",
                        cause: error.localizedDescription
                    ))
            }
        }

        func adaptJson(jsObject: Dictionary<String, Any>?) -> URL? {
            guard let json = jsObject, let value = json["value"] else {
                return nil
            }
            if let dict = value as? Dictionary<String, Any>,
                let url = dict["href"] as? String {
                return URL(string: url)
            }
            if let url = value as? String {
                return URL(string: url)
            }
            logger.error(e: nil) {
                return "Error parsing JSON for Process Deep Link: \(String(describing: jsObject))"
            }
            return nil
        }

        typealias ARGS = URL
    }

    private class GenerateIdentityTransferUrl : ApiBridge {
        private let logger = ServiceLocator.shared.getLogger()

        func invokeInternal(args: URL?) async -> ApiResult {
            do {
                if let url = args {
                    let mxoNative = ServiceLocator.shared.getMXONative()
                    if let url = try mxoNative.generateIdentityTransferUrl(url: url) {
                        logger.debug(e: nil) {
                            return "Generated Identity Transfer Url: \(url)"
                        }
                        return ApiResult.StringApiResult(url.absoluteString)
                    } else {
                        return ApiResult.ErrorApiResult(ApiResult.Error(message: "Invalid Url", apiName: "IdentityTransferConfigurationBridge.GenerateIdentityTransferUrl", cause: nil))
                    }
                } else {
                    return ApiResult.ErrorApiResult(ApiResult.Error(message: "No Url provided", apiName: "IdentityTransferConfigurationBridge.GenerateIdentityTransferUrl", cause: nil))
                }
            } catch {
                return ApiResult.ErrorApiResult(
                    ApiResult.Error(
                        message: "Error Generating Identity Transfer Url",
                        apiName: "IdentityTransferConfigurationBridge.GenerateIdentityTransferUrl",
                        cause: error.localizedDescription
                    ))
            }
        }

        func adaptJson(jsObject: Dictionary<String, Any>?) -> URL? {
            if let json = jsObject, let urlString = json["value"] as? String {
                return URL(string: urlString)
            } else {
                logger.error(e: nil) {
                    return "Error parsing JSON for Generate Identity Transfer Url: \(String(describing: jsObject))"
                }
                return nil
            }
        }

        typealias ARGS = URL
    }

}
