import Foundation
import MedalliaMXO

struct OptOutDeclarations {
    static let keyOptOut = "optOut"
    static let keyOptInOptions = "optInOptions"
}

extension Dictionary<String, Any> {
    func toOptOutConfiguration() -> MXOOptOutConfiguration {
        let builder = (try? ServiceLocator.shared.getMXONative().getOptOutConfiguration()?.builder()) ?? MXOOptOutConfigurationBuilder()
        
        if let optOut = (self[OptOutDeclarations.keyOptOut] as? Bool) {
            builder.optOut = optOut
        }
        
        if let optInOptions = (self[OptOutDeclarations.keyOptInOptions] as? Array<Any>) {
            builder.optInOptions = optInOptions.toOptInOptions()
        } else if let option = (self[OptOutDeclarations.keyOptInOptions] as? String)?.toMxoOptInOption() {
            builder.optInOptions = option
        }
        
        return builder.build()
    }
}

extension Array<Any> {
    func toOptInOptions() -> MXOOptInOptions {
        var options: MXOOptInOptions = []
        
        for index in 0..<self.endIndex {
            if let maybeOption = (self[index] as? String)?.toMxoOptInOption() {
                options.insert(maybeOption)
            }
        }
        
        return options
    }
}

extension String {
    func toMxoOptInOption() -> MXOOptInOptions? {
        switch self {
        case "CITY_COUNTRY_DETECTION": return MXOOptInOptions.cityCountryDetection
        case "INTERACTION_TRACKING": return MXOOptInOptions.interactionTracking
        case "KEYCHAIN_TID_STORAGE": return MXOOptInOptions.keychainTidStorage
        default: return nil
        }
    }
}

extension MXOOptOutConfiguration {
    func toJs() -> [String:Any?] {
        var result: [String:Any?] = [:]
        result[OptOutDeclarations.keyOptOut] = self.optOut
        
        var optInOptions = Array<Any>()
        
        if (self.optInOptions.contains(.cityCountryDetection)) {
            optInOptions.append("CITY_COUNTRY_DETECTION")
        }
        
        if (self.optInOptions.contains(.interactionTracking)) {
            optInOptions.append("INTERACTION_TRACKING")
        }
        
        if (self.optInOptions.contains(.keychainTidStorage)) {
            optInOptions.append("KEYCHAIN_TID_STORAGE")
        }
        
        result [OptOutDeclarations.keyOptInOptions] = optInOptions
        return result
    }
}

public class OptOutBridge {
    public static let setter: any ApiBridge = Setter()
    public static let getter: any ApiBridge = Getter()
    
    private init () { }
    
    private class Setter : ApiBridge {
        private let logger = ServiceLocator.shared.getLogger()
        
        func invokeInternal(args: MXOOptOutConfiguration?) async -> ApiResult {
            do {
                let mxoNative = ServiceLocator.shared.getMXONative()
                try mxoNative.setOptOutConfiguration(config: args)
                logger.debug(e: nil) {
                    let argsString = (args != nil) ? String(describing: args) : "null"
                    return "Set Opt Out Configuration to: \(argsString)"
                }
                return ApiResult.NullApiResult
            } catch {
                return ApiResult.ErrorApiResult(
                    ApiResult.Error(
                        message: "Error setting MXO Opt Out configuration.",
                        apiName: "OptOutBridge.Setter",
                        cause: error.localizedDescription
                    ))
            }
        }
        
        func adaptJson(jsObject: Dictionary<String, Any>?) -> MXOOptOutConfiguration? {
            return jsObject?.toOptOutConfiguration()
        }
        
        typealias ARGS = MXOOptOutConfiguration
    }
    
    private class Getter : ApiBridge {
        private let logger = ServiceLocator.shared.getLogger()
        func invokeInternal(args: Any?) async -> ApiResult {
            do {
                if let current = try ServiceLocator.shared.getMXONative().getOptOutConfiguration() {
                    let result = current.toJs()
                    logger.debug(e: nil) {
                        return "Opt Out Configuration: \(result)"
                    }
                    return ApiResult.JSObjectApiResult(result)
                } else {
                    return ApiResult.NullApiResult
                }
            } catch {
                logger.error(e: error, msg: nil)
                return ApiResult.ErrorApiResult(
                    ApiResult.Error(
                        message: "Error getting MXO Opt Out configuration.",
                        apiName: "OptOutBridge.Getter",
                        cause: error.localizedDescription
                    ))
            }
        }
        
        func adaptJson(jsObject: Dictionary<String, Any>?) -> ARGS? {
            // ignored for getter
            return nil
        }
        
        typealias ARGS = Any
    }
}
