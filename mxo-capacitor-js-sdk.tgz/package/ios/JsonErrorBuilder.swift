import Foundation

class JsonErrorBuilder {
    
    public private(set) var apiName: String? = nil
    public private(set) var message: String? = nil
    public private(set) var cause: String? = nil
    
    public func withMessage(_ message: String?) -> JsonErrorBuilder {
        self.message = message
        return self
    }
    
    public func withApiName(_ apiName: String?) -> JsonErrorBuilder {
        self.apiName = apiName
        return self
    }
    
    public func withCause(_ cause: String?) -> JsonErrorBuilder {
        self.cause = cause
        return self
    }
    
    public func build() -> [String:String] {
        return [
            "apiName": apiName ?? "",
            "message": message ?? "",
            "cause": cause ?? ""
        ]
    }
}
