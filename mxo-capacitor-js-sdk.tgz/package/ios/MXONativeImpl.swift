import Foundation
import MedalliaMXO

/// Implementation of MXONative that calls to MedalliaMXO class methods.
/// BE VERY CAREFUL WHEN EDITING AS GETTING THIS WRONG DOESN'T BREAK UNIT TESTS
class MXONativeImpl : MXONative {
    static let shared: any MXONative = MXONativeImpl()
    
    private init() { }
    
    func getVersion() -> String {
        return MedalliaMXO.getVersion()
    }
    
    func getTid() -> String {
        return MedalliaMXO.getTid() ?? ""
    }

    func clearTid() throws {
        MedalliaMXO.clearTid()
    }

    func setLoggingConfiguration(config: MXOLoggingConfiguration?) throws {
        MedalliaMXO.loggingConfiguration = config
    }
    
    func getLoggingConfiguration() throws -> MXOLoggingConfiguration? {
        return MedalliaMXO.loggingConfiguration
    }

    func setConfiguration(config: MXOConfiguration?) throws {
        MedalliaMXO.configuration = config
    }

    func getConfiguration() throws -> MXOConfiguration? {
        return MedalliaMXO.configuration
    }

    func sendInteraction(request: MXOInteractionRequest) async throws -> MXOInteractionResponse {
        return try await withCheckedThrowingContinuation({ continuation in
            let wrappedRequest = MXOInteractionRequest { builder in
                builder.interaction = request.interaction
                builder.properties = request.properties
                builder.onError = { error in
                    continuation.resume(throwing: error)
                }
                builder.onSuccess = { response in
                    continuation.resume(returning: response)
                }
            }

            do {
                try MedalliaMXO.sendInteraction(request: wrappedRequest)
            } catch {
                continuation.resume(throwing: error)
            }
        })
    }
    
    func sendInteraction(forOutboundLink url: URL) async throws {
        try await withCheckedThrowingContinuation({ continuation in
            do {
                try MedalliaMXO.sendInteraction(forOutboundLink: url)
                continuation.resume()
            } catch {
                continuation.resume(throwing: error)
            }
        })
    }

    func sendProperties(request: MXOInteractionRequest) async throws -> MXOInteractionResponse {
        return try await withCheckedThrowingContinuation({ continuation in
            let wrappedRequest = MXOInteractionRequest { builder in
                builder.interaction = request.interaction
                builder.properties = request.properties
                builder.onError = { error in
                    continuation.resume(throwing: error)
                }
                builder.onSuccess = { response in
                    continuation.resume(returning: response)
                }
            }

            do {
                try MedalliaMXO.sendProperties(request: wrappedRequest)
            } catch {
                continuation.resume(throwing: error)
            }
        })
    }

    func sendInteraction(responseCodeRequest: MXOResponseCodeRequest) async throws -> MXOInteractionResponse {
        return try await withCheckedThrowingContinuation({ continuation in
            let wrappedRequest = MXOResponseCodeRequest { builder in
                builder.interaction = responseCodeRequest.interaction
                builder.responseCode = responseCodeRequest.responseCode
                builder.onError = { error in
                    continuation.resume(throwing: error)
                }
                builder.onSuccess = { response in
                    continuation.resume(returning: response)
                }
            }
            do {
                try MedalliaMXO.sendInteraction(responseCodeRequest: wrappedRequest)
            } catch {
                continuation.resume(throwing: error)
            }
        })
    }

    func process(response: MXOInteractionResponse) async throws {
        try await withCheckedThrowingContinuation({ continuation in
            do {
                try MedalliaMXO.process(response: response)
                continuation.resume()
            } catch {
                continuation.resume(throwing: error)
            }
        })
    }

    func setOptOutConfiguration(config: MXOOptOutConfiguration?) throws {
        MedalliaMXO.optOutConfiguration = config
    }

    func getOptOutConfiguration() throws -> MXOOptOutConfiguration? {
        return MedalliaMXO.optOutConfiguration
    }

    func process(location: CLLocation) throws {
        try MedalliaMXO.process(location: location)
    }

    func setIdentityTransferConfiguration(config: MXOIdentityTransferConfiguration?) throws {
        MedalliaMXO.identityTransferConfiguration = config
    }

    func getIdentityTransferConfiguration() throws -> MXOIdentityTransferConfiguration? {
        return MedalliaMXO.identityTransferConfiguration
    }
    
    func process(deepLink: URL) async throws {
        try await withCheckedThrowingContinuation({ continuation in
            do {
                try MedalliaMXO.process(deepLink: deepLink)
                continuation.resume()
            } catch {
                continuation.resume(throwing: error)
            }
        })
    }
    
    func generateIdentityTransferUrl(url: URL) throws -> URL? {
        return try MedalliaMXO.generateIdentityTransferUrl(url)
    }

    func setAutomaticInteractionTrackingConfiguration(config: MXOAutomaticInteractionTrackingConfiguration?) throws {
        MedalliaMXO.automaticInteractionTrackingConfiguration = config
    }

    func getAutomaticInteractionTrackingConfiguration() throws -> MXOAutomaticInteractionTrackingConfiguration? {
        return MedalliaMXO.automaticInteractionTrackingConfiguration
    }

}
