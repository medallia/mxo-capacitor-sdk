import Foundation
import MedalliaMXO

public class LocationBridge {
    public static let processLocation: any ApiBridge = ProcessLocation()
    
    private init () { }
    
    private class ProcessLocation : ApiBridge {
        private let logger = ServiceLocator.shared.getLogger()
        
        func invokeInternal(args: CLLocation?) async -> ApiResult {
            do {
                if let location = args {
                    let mxoNative = ServiceLocator.shared.getMXONative()
                    logger.debug(e: nil) {
                        return "Process location " + String(describing: location)
                    }
                    try mxoNative.process(location: location)
                    return ApiResult.NullApiResult
                } else {
                    return ApiResult.ErrorApiResult(
                        ApiResult.Error(
                            message: "Invalid location.",
                            apiName: "LocationBridge.ProcessLocation",
                            cause: nil
                        ))
                }
            } catch {
                return ApiResult.ErrorApiResult(
                    ApiResult.Error(
                        message: "Error processing location.",
                        apiName: "LocationBridge.ProcessLocation",
                        cause: error.localizedDescription
                    ))
            }
        }
        
        func adaptJson(jsObject: Dictionary<String, Any>?) -> CLLocation? {
            if let json = jsObject {
                let longitude = json["longitude"] as? Double ?? 0.0
                let long = CLLocationDegrees(floatLiteral: longitude)
                
                let latitude = json["latitude"] as? Double ?? 0.0
                let lat = CLLocationDegrees(floatLiteral: latitude)
                
                let horizontalAccuracy = json["horizontalAccuracy"] as? Double ?? -1.0
                let acc = CLLocationAccuracy(floatLiteral: horizontalAccuracy)
                
                let timeStamp = json["timestamp"] as? Double ?? 0
                let date = timeStamp > 0 ? Date(timeIntervalSince1970: timeStamp / 1000) : Date()
                
                let coordinate = CLLocationCoordinate2DMake(lat, long)
                return CLLocation(coordinate: coordinate, altitude: 0, horizontalAccuracy: acc, verticalAccuracy: -1, timestamp: date)
            } else {
                return nil
            }
        }
        
        typealias ARGS = CLLocation
    }
}
