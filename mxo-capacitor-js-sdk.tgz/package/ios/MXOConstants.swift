import Foundation

struct MXOConstants {
    static let MXO_HYBRID_SDK_VERSION = "4.1.0"
    static let CAPACITOR_VERSION = "7.4.2"
}
