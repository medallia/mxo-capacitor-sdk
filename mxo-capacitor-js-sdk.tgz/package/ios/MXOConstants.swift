import Foundation

struct MXOConstants {
    static let MXO_SDK_VERSION = "4.0.3"
    static let CAPACITOR_VERSION = "7.4.2"
}
