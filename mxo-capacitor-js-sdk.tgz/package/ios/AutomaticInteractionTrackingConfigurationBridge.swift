import Foundation
import MedalliaMXO

struct AutomaticInteractionTrackingDeclarations {
    static let disableInteractionTracking = "disableInteractionTracking"
    static let disableOutboundLinkTracking = "disableOutboundLinkTracking"
}

extension Dictionary<String, Any> {
    func toMxoAutomaticInteractionTrackingConfiguration() -> MXOAutomaticInteractionTrackingConfiguration {
        let builder = (try? ServiceLocator.shared.getMXONative().getAutomaticInteractionTrackingConfiguration()?.builder()) ?? MXOAutomaticInteractionTrackingConfigurationBuilder()
        
        if let disableInteractionTracking = (self[AutomaticInteractionTrackingDeclarations.disableInteractionTracking] as? Bool) {
            builder.disableInteractionTracking = disableInteractionTracking
        }
        
        if let disableOutboundLinkTracking = (self[AutomaticInteractionTrackingDeclarations.disableOutboundLinkTracking] as? Bool) {
            builder.disableOutboundLinkTracking = disableOutboundLinkTracking
        }
        
        return builder.build()
    }
}

extension MXOAutomaticInteractionTrackingConfiguration {
    func toJs() -> [String:Any?] {
        var result: [String:Any?] = [:]
        result[AutomaticInteractionTrackingDeclarations.disableInteractionTracking] = self.disableInteractionTracking
        result[AutomaticInteractionTrackingDeclarations.disableOutboundLinkTracking] = self.disableOutboundLinkTracking
        return result
    }
}

public class AutomaticInteractionTrackingConfigurationBridge {
    public static let setter: any ApiBridge = Setter()
    public static let getter: any ApiBridge = Getter()
    
    private init () { }
    
    private class Setter : ApiBridge {
        private let logger = ServiceLocator.shared.getLogger()
        
        func invokeInternal(args: MXOAutomaticInteractionTrackingConfiguration?) async -> ApiResult {
            do {
                let mxoNative = ServiceLocator.shared.getMXONative()
                try mxoNative.setAutomaticInteractionTrackingConfiguration(config: args)
                logger.debug(e: nil) {
                    let argsString = (args != nil) ? String(describing: args) : "null"
                    return "Set Automatic Interaction Tracking Configuration to: \(argsString)"
                }
                return ApiResult.NullApiResult
            } catch {
                return ApiResult.ErrorApiResult(
                    ApiResult.Error(
                        message: "Error setting MXO Automatic Interaction Tracking configuration.",
                        apiName: "AutomaticInteractionTrackingConfigurationBridge.Setter",
                        cause: error.localizedDescription
                    ))
            }
        }
        
        
        func adaptJson(jsObject: Dictionary<String, Any>?) -> MXOAutomaticInteractionTrackingConfiguration? {
            return jsObject?.toMxoAutomaticInteractionTrackingConfiguration()
        }
        
        typealias ARGS = MXOAutomaticInteractionTrackingConfiguration
    }
    
    private class Getter : ApiBridge {
        private let logger = ServiceLocator.shared.getLogger()
        func invokeInternal(args: Any?) async -> ApiResult {
            do {
                if let current = try ServiceLocator.shared.getMXONative().getAutomaticInteractionTrackingConfiguration() {
                    let result = current.toJs()
                    logger.debug(e: nil) {
                        return "Automatic Interaction Tracking Configuration: \(result)"
                    }
                    return ApiResult.JSObjectApiResult(result)
                } else {
                    return ApiResult.NullApiResult
                }
            } catch {
                logger.error(e: error, msg: nil)
                return ApiResult.ErrorApiResult(
                    ApiResult.Error(
                        message: "Error getting MXO Automatic Interaction Tracking configuration.",
                        apiName: "AutomaticInteractionTrackingConfigurationBridge.Getter",
                        cause: error.localizedDescription
                    ))
            }
        }
        
        func adaptJson(jsObject: Dictionary<String, Any>?) -> ARGS? {
            // ignored for getter
            return nil
        }
        
        typealias ARGS = Any
    }
}
