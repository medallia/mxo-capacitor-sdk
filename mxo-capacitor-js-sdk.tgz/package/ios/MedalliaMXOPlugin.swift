import Foundation
import Capacitor
import MedalliaMXO

/**
 * Please read the Capacitor iOS Plugin Development Guide
 * here: https://capacitorjs.com/docs/plugins/ios
 */
@objc(MedalliaMXOPlugin)
public class MedalliaMXOPlugin: CAPPlugin {
    private class Telemetry {
        let name: String
        let version: String
        let sdkVersion: String
        init(name: String, version: String, sdkVersion: String) {
            self.name = name
            self.version = version
            self.sdkVersion = sdkVersion
        }
    }

    override public func load() {
        MedalliaMXO.loggingConfiguration = MXOLoggingConfiguration { builder in
            builder.logLevel = MXOLogLevel.debug
            builder.logComponent = MXOLogComponent.any
        }
        ServiceLocator.shared.getLogger().debug(e: nil) {
            return "MXO CapacitorJS SDK does not support Automatic Interaction Tracking. Disabling."
        }
        MedalliaMXO.automaticInteractionTrackingConfiguration = MXOAutomaticInteractionTrackingConfiguration { builder in
            builder.disableInteractionTracking = true
        }

        let selectorSetTelemetryFramework = NSSelectorFromString("setTelemetryFramework:")

        if (MedalliaMXO.responds(to: selectorSetTelemetryFramework)) {
            MedalliaMXO.perform(
                selectorSetTelemetryFramework,
                with: Telemetry(
                    name: "capacitor",
                    version: MXOConstants.CAPACITOR_VERSION,
                    sdkVersion: MXOConstants.MXO_SDK_VERSION
                )
            )
            ServiceLocator.shared.getLogger().debug(e: nil) {
                return "MXO set capacitor version to \(MXOConstants.CAPACITOR_VERSION)"
            }
        } else {
            ServiceLocator.shared.getLogger().debug(e: nil) {
                return "MXO could not set capacitor version."
            }
        }

        MedalliaMXO.loggingConfiguration = MXOLoggingConfiguration { builder in
            builder.logLevel = MXOLogLevel.none
            builder.logComponent = MXOLogComponent.none
        }
    }
    
    private func notImplemented(_ call: CAPPluginCall) async ->  Void {
        call.unimplemented()
    }
    
    private func getBridgeCall(withCAPCall call: CAPPluginCall) -> BridgeCall {
        let bridgeCall = BridgeCall(
            jsObjectRepresentation: call.jsObjectRepresentation
        ) { result in
            if let result = result {
                call.resolve(result)
            } else {
                call.resolve()
            }
        } reject: { message, error, result in
            call.reject(message ?? "error", "-1", error, result)
        }
        return bridgeCall
    }

    @objc func getConfiguration(_ call: CAPPluginCall) {
        Task.detached(priority: .userInitiated) {
            await ConfigurationBridge.getter.invoke(self.getBridgeCall(withCAPCall: call), "getConfiguration")
        }
    }
    
    @objc func setConfiguration(_ call: CAPPluginCall) {
        Task.detached(priority: .userInitiated) {
            await ConfigurationBridge.setter.invoke(self.getBridgeCall(withCAPCall: call), "setConfiguration")
        }
    }
    
    @objc func getLoggingConfiguration(_ call: CAPPluginCall) {
        Task.detached(priority: .userInitiated) {
            await LoggingBridge.getter.invoke(self.getBridgeCall(withCAPCall: call), "getLoggingConfiguration")
        }
    }
    
    @objc func setLoggingConfiguration(_ call: CAPPluginCall) {
        Task.detached(priority: .userInitiated) {
            await LoggingBridge.setter.invoke(self.getBridgeCall(withCAPCall: call), "setLoggingConfiguration")
        }
    }
    
    @objc func getAutomaticInteractionTrackingConfiguration(_ call: CAPPluginCall) {
        Task.detached(priority: .userInitiated) {
            await AutomaticInteractionTrackingConfigurationBridge.getter.invoke(self.getBridgeCall(withCAPCall: call), "getAutomaticInteractionTrackingConfiguration")
        }
    }
    
    @objc func setAutomaticInteractionTrackingConfiguration(_ call: CAPPluginCall) {
        Task.detached(priority: .userInitiated) {
            await AutomaticInteractionTrackingConfigurationBridge.setter.invoke(self.getBridgeCall(withCAPCall: call), "setAutomaticInteractionTrackingConfiguration")
        }
    }
    
    @objc func getIdentityTransferConfiguration(_ call: CAPPluginCall) {
        Task.detached(priority: .userInitiated) {
            await IdentityTransferConfigurationBridge.getter.invoke(self.getBridgeCall(withCAPCall: call), "getIdentityTransferConfiguration")
        }
    }
    
    @objc func setIdentityTransferConfiguration(_ call: CAPPluginCall) {
        Task.detached(priority: .userInitiated) {
            await IdentityTransferConfigurationBridge.setter.invoke(self.getBridgeCall(withCAPCall: call), "setIdentityTransferConfiguration")
        }
    }

    @objc func getVersion(_ call: CAPPluginCall) {
        Task.detached(priority: .userInitiated) {
            await VersionBridge.getter.invoke(self.getBridgeCall(withCAPCall: call), "getVersion")
        }
    }
    
    @objc func getTid(_ call: CAPPluginCall) {
        Task.detached(priority: .userInitiated) {
            await TidBridge.getter.invoke(self.getBridgeCall(withCAPCall: call), "getTid")
        }
    }
    
    @objc func clearTid(_ call: CAPPluginCall) {
        Task.detached(priority: .userInitiated) {
            await TidBridge.clear.invoke(self.getBridgeCall(withCAPCall: call), "clearTid")
        }
    }
    
    @objc func processLocation(_ call: CAPPluginCall) {
        Task.detached(priority: .userInitiated) {
            await LocationBridge.processLocation.invoke(self.getBridgeCall(withCAPCall: call), "processLocation")
        }
    }

    @objc func sendInteraction(_ call: CAPPluginCall) {
        Task.detached(priority: .userInitiated) {
            await InteractionBridge.send.invoke(self.getBridgeCall(withCAPCall: call), "sendInteraction")
        }
    }
    
    @objc func sendProperties(_ call: CAPPluginCall) {
        Task.detached(priority: .userInitiated) {
            await InteractionBridge.sendProperties.invoke(self.getBridgeCall(withCAPCall: call), "sendProperties")
        }
    }
    
    @objc func sendInteractionResponseCode(_ call: CAPPluginCall) {
        Task.detached(priority: .userInitiated) {
            await InteractionBridge.sendInteractionResponseCode.invoke(self.getBridgeCall(withCAPCall: call), "sendInteractionResponseCode")
        }
    }
    
    @objc func sendInteractionForOutboundLink(_ call: CAPPluginCall) {
        Task.detached(priority: .userInitiated) {
            await InteractionBridge.sendInteractionForOutboundLink.invoke(self.getBridgeCall(withCAPCall: call), "sendInteractionForOutboundLink")
        }
    }
    
    @objc func processResponse(_ call: CAPPluginCall) {
        Task.detached(priority: .userInitiated) {
            await InteractionBridge.processResponse.invoke(self.getBridgeCall(withCAPCall: call), "processResponse")
        }
    }

    @objc func getOptOutConfiguration(_ call: CAPPluginCall) {
        Task.detached(priority: .userInitiated) {
            await OptOutBridge.getter.invoke(self.getBridgeCall(withCAPCall: call), "getOptOutConfiguration")
        }
    }

    @objc func setOptOutConfiguration(_ call: CAPPluginCall) {
        Task.detached(priority: .userInitiated) {
            await OptOutBridge.setter.invoke(self.getBridgeCall(withCAPCall: call), "setOptOutConfiguration")
        }
    }
    
    @objc func processDeeplink(_ call: CAPPluginCall) {
        Task.detached(priority: .userInitiated) {
            await IdentityTransferConfigurationBridge.processDeeplink.invoke(self.getBridgeCall(withCAPCall: call), "processDeeplink")
        }
    }
    
    @objc func generateIdentityTransferUrl(_ call: CAPPluginCall) {
        Task.detached(priority: .userInitiated) {
            await IdentityTransferConfigurationBridge.generateIdentityTransferUrl.invoke(self.getBridgeCall(withCAPCall: call), "generateIdentityTransferUrl")
        }
    }

}
