#import <Foundation/Foundation.h>
#import <Capacitor/Capacitor.h>

// Define the plugin using the CAP_PLUGIN Macro, and
// each method the plugin supports using the CAP_PLUGIN_METHOD macro.
CAP_PLUGIN(MedalliaMXOPlugin, "MedalliaMXO",
           CAP_PLUGIN_METHOD(getConfiguration, CAPPluginReturnPromise);
           CAP_PLUGIN_METHOD(setConfiguration, CAPPluginReturnPromise);
           
           CAP_PLUGIN_METHOD(getOptOutConfiguration, CAPPluginReturnPromise);
           CAP_PLUGIN_METHOD(setOptOutConfiguration, CAPPluginReturnPromise);
           
           CAP_PLUGIN_METHOD(getLoggingConfiguration, CAPPluginReturnPromise);
           CAP_PLUGIN_METHOD(setLoggingConfiguration, CAPPluginReturnPromise);
           
           CAP_PLUGIN_METHOD(getAutomaticInteractionTrackingConfiguration, CAPPluginReturnPromise);
           CAP_PLUGIN_METHOD(setAutomaticInteractionTrackingConfiguration, CAPPluginReturnPromise);
           
           CAP_PLUGIN_METHOD(getIdentityTransferConfiguration, CAPPluginReturnPromise);
           CAP_PLUGIN_METHOD(setIdentityTransferConfiguration, CAPPluginReturnPromise);
           
           CAP_PLUGIN_METHOD(getVersion, CAPPluginReturnPromise);
           
           CAP_PLUGIN_METHOD(getTid, CAPPluginReturnPromise);
           CAP_PLUGIN_METHOD(clearTid, CAPPluginReturnPromise);
           
           CAP_PLUGIN_METHOD(processLocation, CAPPluginReturnPromise);
           
           CAP_PLUGIN_METHOD(sendInteraction, CAPPluginReturnPromise);
           CAP_PLUGIN_METHOD(sendProperties, CAPPluginReturnPromise);
           CAP_PLUGIN_METHOD(sendInteractionResponseCode, CAPPluginReturnPromise);
           CAP_PLUGIN_METHOD(sendInteractionForOutboundLink, CAPPluginReturnPromise);
           CAP_PLUGIN_METHOD(processResponse, CAPPluginReturnPromise);
           
           CAP_PLUGIN_METHOD(processDeeplink, CAPPluginReturnPromise);
           CAP_PLUGIN_METHOD(generateIdentityTransferUrl, CAPPluginReturnPromise);
)
