import Foundation

public typealias MXOPromiseResolveBlock = ([String:Any?]?) -> Void
public typealias MXOPromiseRejectBlock = (String?, NSError?, [String:Any?]?) -> Void

public class BridgeCall: NSObject {

    var jsObjectRepresentation: Dictionary<String, Any>?

    public var _resolve: MXOPromiseResolveBlock
    public var _reject: MXOPromiseRejectBlock

    public init(jsObjectRepresentation: Dictionary<String, Any>?, resolve _resolve: @escaping MXOPromiseResolveBlock, reject _reject: @escaping MXOPromiseRejectBlock) {
        self.jsObjectRepresentation = jsObjectRepresentation
        self._resolve = _resolve
        self._reject = _reject
    }

    func resolve(resolved: [String:Any?]? = nil) {
        _resolve(resolved)
    }

    func reject(msg: String?, error:NSError?, result: [String:Any?]? = nil) {
        _reject(msg, error, result)
    }
}
