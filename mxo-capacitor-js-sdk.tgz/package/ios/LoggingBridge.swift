import Foundation
import MedalliaMXO

struct LoggingDeclarations {
    static let keyLogLevel = "levels"
    static let keyLogLevelDebug = "debug"
    static let keyLogLevelVerbose = "verbose"
    static let keyLogLevelNone = "none"
    static let keyLogLevelError = "error"
    static let keyLogLevelWarn = "warn"
    static let keyLogLevelInfo = "info"
    
    static let keyLogComponent = "components"
    static let keyLogComponentAny = "any"
    static let keyLogComponentNone = "none"
    static let keyLogComponentInteraction = "interaction"
    static let keyLogComponentNetworking = "networking"
}

extension Dictionary<String, Any> {
    func toMxoLoggingConfiguration() -> MXOLoggingConfiguration {
        let builder = (try? ServiceLocator.shared.getMXONative().getLoggingConfiguration()?.builder()) ?? MXOLoggingConfigurationBuilder()
        
        if let singleLevel = (self[LoggingDeclarations.keyLogLevel] as? String)?.toMxoLogLevel() {
            builder.logLevel = singleLevel
        } else if let arrayLevels = (self[LoggingDeclarations.keyLogLevel] as? Array<Any>)?.toMxoLogLevel() {
            builder.logLevel = arrayLevels
        }
        
        if let singleComponent = (self[LoggingDeclarations.keyLogComponent] as? String)?.toMxoLogComponent() {
            builder.logComponent = singleComponent
        } else if let arrayComponents = (self[LoggingDeclarations.keyLogComponent] as? Array<Any>)?.toMxoLogComponent() {
            builder.logComponent = arrayComponents
        }
        
        return builder.build()
    }
}

extension Array<Any> {
    func toMxoLogLevel() -> MXOLogLevel {
        var level: MXOLogLevel = []
        
        for index in 0..<self.endIndex {
            if let maybeLevel = (self[index] as? String)?.toMxoLogLevel() {
                level.insert(maybeLevel)
            }
        }
        
        if level.isEmpty {
            return MXOLogLevel.none
        } else {
            return level
        }
    }
    
    func toMxoLogComponent() -> MXOLogComponent {
        var component: MXOLogComponent = []
        
        for index in 0..<self.endIndex {
            if let maybeComponent = (self[index] as? String)?.toMxoLogComponent() {
                component.insert(maybeComponent)
            }
        }
        
        if component.isEmpty {
            return MXOLogComponent.none
        } else {
            return component
        }
    }
}

extension String {
    func toMxoLogLevel() -> MXOLogLevel? {
        switch (self.lowercased()) {
        case LoggingDeclarations.keyLogLevelDebug:
            return MXOLogLevel.debug
        case LoggingDeclarations.keyLogLevelWarn:
            return MXOLogLevel.warn
        case LoggingDeclarations.keyLogLevelVerbose:
            return MXOLogLevel.verbose
        case LoggingDeclarations.keyLogLevelError:
            return MXOLogLevel.error
        case LoggingDeclarations.keyLogLevelInfo:
            return MXOLogLevel.info
        case LoggingDeclarations.keyLogLevelNone:
            return MXOLogLevel.none
        default:
            return nil
        }
    }
    
    func toMxoLogComponent() -> MXOLogComponent? {
        switch (self.lowercased()) {
        case LoggingDeclarations.keyLogComponentAny:
            return MXOLogComponent.any
        case LoggingDeclarations.keyLogComponentInteraction:
            return MXOLogComponent.interaction
        case LoggingDeclarations.keyLogComponentNetworking:
            return MXOLogComponent.networking
        case LoggingDeclarations.keyLogComponentNone:
            return MXOLogComponent.none
        default:
            return nil
        }
    }
}

extension MXOLogLevel {
    func toJsArray() -> Array<Any> {
        var result = Array<Any>()
        
        if self.contains(MXOLogLevel.debug) {
            result.append(LoggingDeclarations.keyLogLevelDebug.uppercased())
        }
        
        if self.contains(MXOLogLevel.error) {
            result.append(LoggingDeclarations.keyLogLevelError.uppercased())
        }
        
        if self.contains(MXOLogLevel.info) {
            result.append(LoggingDeclarations.keyLogLevelInfo.uppercased())
        }
        
        if self.contains(MXOLogLevel.none) {
            result.append(LoggingDeclarations.keyLogLevelNone.uppercased())
        }
        
        if self.contains(MXOLogLevel.verbose) {
            result.append(LoggingDeclarations.keyLogLevelVerbose.uppercased())
        }
        
        if self.contains(MXOLogLevel.warn) {
            result.append(LoggingDeclarations.keyLogLevelWarn.uppercased())
        }
        
        return result
    }
}

extension MXOLogComponent {
    func toJsArray() -> Array<Any> {
        var result = Array<Any>()
        
        if self.contains(MXOLogComponent.any) {
            result.append(LoggingDeclarations.keyLogComponentAny.uppercased())
        }
        
        if self.contains(MXOLogComponent.none) {
            result.append(LoggingDeclarations.keyLogComponentNone.uppercased())
        }
        
        if self.contains(MXOLogComponent.interaction) {
            result.append(LoggingDeclarations.keyLogComponentInteraction.uppercased())
        }
        
        if self.contains(MXOLogComponent.networking) {
            result.append(LoggingDeclarations.keyLogComponentNetworking.uppercased())
        }
        
        return result
    }
}

extension MXOLoggingConfiguration {
    func toJs() -> [String:Any?] {
        var result: [String:Any?] = [:]
        result[LoggingDeclarations.keyLogLevel] = self.logLevel.toJsArray()
        result[LoggingDeclarations.keyLogComponent] = self.logComponent.toJsArray()
        return result
    }
}


public class LoggingBridge {
    public static let setter: any ApiBridge = Setter()
    public static let getter: any ApiBridge = Getter()
    
    private init () { }
    
    private class Setter : ApiBridge {
        private let logger = ServiceLocator.shared.getLogger()
        
        func invokeInternal(args: MXOLoggingConfiguration?) async -> ApiResult {
            do {
                let mxoNative = ServiceLocator.shared.getMXONative()
                try mxoNative.setLoggingConfiguration(config: args)
                logger.debug(e: nil) {
                    let argsString = (args != nil) ? String(describing: args) : "null"
                    return "Set Logging Configuration to \(argsString)"
                }
                return ApiResult.NullApiResult
            } catch {
                return ApiResult.ErrorApiResult(
                    ApiResult.Error(
                        message: "Error setting MXO Logging configuration.",
                        apiName: "LoggingBridge.Setter",
                        cause: error.localizedDescription
                    ))
            }
        }
        
        func adaptJson(jsObject: Dictionary<String, Any>?) -> MXOLoggingConfiguration? {
            return jsObject?.toMxoLoggingConfiguration()
        }
        
        typealias ARGS = MXOLoggingConfiguration
    }
    
    private class Getter : ApiBridge {
        private let logger = ServiceLocator.shared.getLogger()
        func invokeInternal(args: Any?) async -> ApiResult {
            do {
                if let current = try ServiceLocator.shared.getMXONative().getLoggingConfiguration() {
                    let result = current.toJs()
                    logger.debug(e: nil) {
                        return "Logging Configuration: \(result)"
                    }
                    return ApiResult.JSObjectApiResult(result)
                } else {
                    return ApiResult.NullApiResult
                }
            } catch {
                logger.error(e: error, msg: nil)
                return ApiResult.ErrorApiResult(
                    ApiResult.Error(
                        message: "Error getting MXO Logging configuration.",
                        apiName: "LoggingBridge.Getter",
                        cause: error.localizedDescription
                    ))
            }
        }
        
        func adaptJson(jsObject: Dictionary<String, Any>?) -> ARGS? {
            // ignored for getter
            return nil
        }
        
        typealias ARGS = Any
    }
}
