import MedalliaMXO
import Foundation

/// Boundary interface to separate Hybrid from Native so we can mock out the class method calls to MedalliaMXO
public protocol MXONative {
    func getVersion() throws -> String
    
    func getTid() throws -> String
    func clearTid() throws

    func setLoggingConfiguration(config: MXOLoggingConfiguration?) throws
    func getLoggingConfiguration() throws -> MXOLoggingConfiguration?

    func setConfiguration(config: MXOConfiguration?) throws
    func getConfiguration() throws -> MXOConfiguration?

    func sendInteraction(request: MXOInteractionRequest) async throws -> MXOInteractionResponse
    func sendInteraction(forOutboundLink url: URL) async throws
    func sendInteraction(responseCodeRequest: MXOResponseCodeRequest) async throws -> MXOInteractionResponse
    func sendProperties(request: MXOInteractionRequest) async throws -> MXOInteractionResponse
    func process(response: MXOInteractionResponse) async throws

    func setOptOutConfiguration(config: MXOOptOutConfiguration?) throws
    func getOptOutConfiguration() throws -> MXOOptOutConfiguration?

    func process(location: CLLocation) throws

    func setIdentityTransferConfiguration(config: MXOIdentityTransferConfiguration?) throws
    func getIdentityTransferConfiguration() throws -> MXOIdentityTransferConfiguration?

    func process(deepLink: URL) async throws
    func generateIdentityTransferUrl(url: URL) throws -> URL?
    
    func setAutomaticInteractionTrackingConfiguration(config: MXOAutomaticInteractionTrackingConfiguration?) throws
    func getAutomaticInteractionTrackingConfiguration() throws -> MXOAutomaticInteractionTrackingConfiguration?
}
