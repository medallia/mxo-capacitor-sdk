import Foundation
import MedalliaMXO

struct InteractionDeclarations {
    static let keyInteraction = "interaction"
    static let keyProperties = "properties"
    static let keyTid = "tid"
    static let keyIsSuccess = "isSuccess"
    static let keyCaptureActivityPoints = "captureActivityPoints"
    static let keyCaptureAttributePoints = "captureAttributePoints"
    static let keyOptimizationPoints = "optimizationPoints"
    static let keyElementType = "elementType"
    static let keyCaptureType = "captureType"
    static let keyCapturePhase = "capturePhase"
    static let keyDirectives = "directives"
    static let keyMimeType = "mimeType"
}

extension Dictionary<String, Any> {
    func toMxoInteractionRequest() throws -> MXOInteractionRequest {
        let interaction = try MXOInteraction(withString: (self[InteractionDeclarations.keyInteraction] as? String) ?? "")
        return MXOInteractionRequest { builder in
            builder.interaction = interaction
            if let properties = (self[InteractionDeclarations.keyProperties] as? [String:String]) {
                builder.properties = properties
            }
        }
    }

    func toMxoInteractionResponse() throws -> MXOInteractionResponse? {
        if let rawResponse = self["_rawResponse"] as? Dictionary {
            let response = MXOInteractionResponse()
            response.setValue(rawResponse, forKey: "rawResponse")
            return response
        }
        return nil
    }

    func toMxoResponseCodeRequest() throws -> MXOResponseCodeRequest? {
        let interaction = try MXOInteraction(withString: (self[InteractionDeclarations.keyInteraction] as? String) ?? "")
        var code: MXOResponseCode? = nil
        if let maybeCode = (self["responseCode"] as? String) {
            code = try MXOResponseCode(withResponseCode: maybeCode)
        }

        return MXOResponseCodeRequest { builder in
            builder.interaction = interaction
            builder.responseCode = code
        }
    }
}

extension MXOCaptureActivityPoint {
    func toJs() -> [String:Any?] {
        var result: [String:Any?] = [:]
        result["path"] = self.path
        result["id"] = self.identifier
        return result
    }
}

extension MXOCaptureAttributePoint {
    func toJs() -> [String:Any?] {
        var result: [String:Any?] = [:]

        result["id"] = self.identifier
        result["path"] = self.path
        result["elementName"] = self.elementName
        result["elementAttributeName"] = self.elementAttributeName
        result["captureDelay"] = self.captureDelay

        switch self.elementType {
        case .textfield: result[InteractionDeclarations.keyElementType] = "TEXT_FIELD"
        case .drop_down: result[InteractionDeclarations.keyElementType] = "DROP_DOWN"
        case .display_elem: result[InteractionDeclarations.keyElementType] = "DISPLAY_ELEM"
        case .checkbox_radio: result[InteractionDeclarations.keyElementType] = "CHECKBOX_RADIO"
        default: result[InteractionDeclarations.keyElementType] = ""
        }

        switch self.captureType {
        case .attribute: result[InteractionDeclarations.keyCaptureType] = "ATTRIBUTE"
        case .cookie: result[InteractionDeclarations.keyCaptureType] = "COOKIE"
        case .text: result[InteractionDeclarations.keyCaptureType] = "TEXT"
        case .value: result[InteractionDeclarations.keyCaptureType] = "VALUE"
        default: result[InteractionDeclarations.keyCaptureType] = ""
        }

        switch self.capturePhase {
        case .on_click: result[InteractionDeclarations.keyCapturePhase] = "ONCLICK"
        case .phase_load: result[InteractionDeclarations.keyCapturePhase] = "LOAD"
        case .parameter: result[InteractionDeclarations.keyCapturePhase] = "PARAMETER"
        default: result[InteractionDeclarations.keyCapturePhase] = ""
        }

        return result
    }
}

extension MXOAssetResponse {
    func toJs() -> [String:Any?] {
        var result: [String:Any?] = [:]

        result["code"] = self.code?.value
        result["label"] = self.label
        result["imageUrl"] = self.imageUrl
        result["targetUrl"] = self.targetUrl

        switch self.target {
        case .context: result["target"] = "TARGET"
        case .external: result["target"] = "EXTERNAL"
        case .in_app: result["target"] = "IN_APP"
        case .unknown: result["target"] = "UNKNOWN"
        default: result["target"] = "UNKNOWN"
        }

        switch self.sentiment {
        case .negative: result["sentiment"] = "NEGATIVE"
        case .neutral: result["sentiment"] = "NEUTRAL"
        case .positive: result["sentiment"] = "POSITIVE"
        default: result["sentiment"] = ""
        }

        return result
    }
}

extension MXOAsset {
    func toJs() -> [String:Any?] {
        var result: [String:Any?] = [:]
        result["markup"] = self.markup
        result["responses"] = self.responses?.map { response in return response.toJs() }
        result["contentUrl"] = self.contentUrl

        switch self.mimeType {
        case .external: result[InteractionDeclarations.keyMimeType] = "EXTERNAL"
        case .html: result[InteractionDeclarations.keyMimeType] = "HTML"
        case .json: result[InteractionDeclarations.keyMimeType] = "JSON"
        case .txt: result[InteractionDeclarations.keyMimeType] = "TXT"
        case .xml: result[InteractionDeclarations.keyMimeType] = "XML"
        default: result[InteractionDeclarations.keyMimeType] = ""
        }

        return result
    }
}

extension MXOProposition {
    func toJs() -> [String: Any?] {
        var result: [String:Any?] = [:]
        result["name"] = self.name
        result["code"] = self.code

        switch self.type {
        case .product: result["type"] = "PRODUCT"
        case .service: result["type"] = "SERVICE"
        default: result["type"] = ""
        }

        return result
    }
}

extension MXOAction {
    func toJs() -> [String:Any?] {
        var result: [String:Any?] = [:]
        result["name"] = self.name
        result["asset"] = self.asset?.toJs()
        result["proposition"] = self.proposition?.toJs()
        return result
    }
}

extension MXOOptimizationPoint {
    func toJs() -> [String:Any?] {
        var result: [String:Any?] = [:]

        result["path"] = self.path
        result["actions"] = self.actions?.map { action in return action.toJs() }

        switch self.directives {
        case .after: result[InteractionDeclarations.keyDirectives] = "AFTER"
        case .before: result[InteractionDeclarations.keyDirectives] = "BEFORE"
        case .replace: result[InteractionDeclarations.keyDirectives] = "REPLACE"
        default: result[InteractionDeclarations.keyDirectives] = ""
        }

        return result
    }
}

extension MXOInteractionResponse {
    func toJs() -> [String:Any?] {
        var result: [String:Any?] = [:]
        result[InteractionDeclarations.keyTid] = self.tid ?? ""
        result[InteractionDeclarations.keyIsSuccess] = true
        result[InteractionDeclarations.keyInteraction] = self.interaction?.value?.absoluteString
        result[InteractionDeclarations.keyCaptureActivityPoints] = self.captureActivityPoints?.map { point in
            return point.toJs()
        }
        result[InteractionDeclarations.keyCaptureAttributePoints] = self.captureAttributePoints?.map { point in
            return point.toJs()
        }
        result[InteractionDeclarations.keyOptimizationPoints] = self.optimizationPoints?.map { point in
            return point.toJs()
        }

        result["_rawResponse"] = self.value(forKey: "rawResponse")
        return result
    }
}

public class InteractionBridge {
    public static let send: any ApiBridge = Send()
    public static let sendProperties: any ApiBridge = SendProperties()
    public static let processResponse: any ApiBridge = ProcessResponse()
    public static let sendInteractionResponseCode: any ApiBridge = SendInteractionResponseCode()
    public static let sendInteractionForOutboundLink: any ApiBridge = SendInteractionForOutboundLink()

    private init () { }

    private class ProcessResponse : ApiBridge {
        private let logger = ServiceLocator.shared.getLogger()

        func invokeInternal(args: MXOInteractionResponse?) async -> ApiResult {
            do {
                if let response = args {
                    let mxoNative = ServiceLocator.shared.getMXONative()
                    try await mxoNative.process(response: response)
                    logger.debug(e: nil) {
                        return "Processed response: \(response)"
                    }
                    return ApiResult.NullApiResult
                } else {
                    return ApiResult.ErrorApiResult(ApiResult.Error(message: "Invalid Interaction Response", apiName: "InteractionBridge.ProcessResponse", cause: nil))
                }
            } catch {
                return ApiResult.ErrorApiResult(
                    ApiResult.Error(
                        message: "Error Processing MXO Interaction Response",
                        apiName: "InteractionBridge.ProcessResponse",
                        cause: error.localizedDescription
                    ))
            }
        }

        func adaptJson(jsObject: Dictionary<String, Any>?) -> MXOInteractionResponse? {
            do {
                return try jsObject?.toMxoInteractionResponse()
            } catch {
                logger.error(e: error) {
                    return "Error parsing JSON for Interaction Response."
                }
                return nil
            }
        }

        typealias ARGS = MXOInteractionResponse
    }

    private class Send : ApiBridge {
        private let logger = ServiceLocator.shared.getLogger()

        func invokeInternal(args: MXOInteractionRequest?) async -> ApiResult {
            do {
                if let request = args {
                    let mxoNative = ServiceLocator.shared.getMXONative()
                    let response = try await mxoNative.sendInteraction(request: request)
                    logger.debug(e: nil) {
                        let responseString = String(describing: response)
                        return "Interaction Response: \(responseString)"
                    }
                    return ApiResult.JSObjectApiResult(response.toJs())
                } else {
                    return ApiResult.ErrorApiResult(ApiResult.Error(message: "Invalid Interaction Request", apiName: "InteractionBridge.Send", cause: nil))
                }
            } catch {
                return ApiResult.ErrorApiResult(
                    ApiResult.Error(
                        message: "Error sending MXO Interaction.",
                        apiName: "InteractionBridge.Send",
                        cause: error.localizedDescription
                    ))
            }
        }

        func adaptJson(jsObject: Dictionary<String, Any>?) -> MXOInteractionRequest? {
            do {
                return try jsObject?.toMxoInteractionRequest()
            } catch {
                logger.error(e: error) {
                    return "Error parsing JSON for Interaction Request."
                }
                return nil
            }
        }

        typealias ARGS = MXOInteractionRequest
    }

    private class SendProperties : ApiBridge {
        private let logger = ServiceLocator.shared.getLogger()

        func invokeInternal(args: MXOInteractionRequest?) async -> ApiResult {
            do {
                if let request = args {
                    let mxoNative = ServiceLocator.shared.getMXONative()
                    let response = try await mxoNative.sendProperties(request: request)
                    logger.debug(e: nil) {
                        let responseString = String(describing: response)
                        return "Properties Response: \(responseString)"
                    }
                    return ApiResult.JSObjectApiResult(response.toJs())
                } else {
                    return ApiResult.ErrorApiResult(ApiResult.Error(message: "Invalid Properties Request", apiName: "InteractionBridge.SendProperties", cause: nil))
                }
            } catch {
                return ApiResult.ErrorApiResult(
                    ApiResult.Error(
                        message: "Error sending MXO Properties.",
                        apiName: "InteractionBridge.SendProperties",
                        cause: error.localizedDescription
                    ))
            }
        }

        func adaptJson(jsObject: Dictionary<String, Any>?) -> MXOInteractionRequest? {
            do {
                return try jsObject?.toMxoInteractionRequest()
            } catch {
                logger.error(e: error) {
                    return "Error parsing JSON for Properties Request."
                }
                return nil
            }
        }

        typealias ARGS = MXOInteractionRequest
    }

    private class SendInteractionResponseCode: ApiBridge {
        private let logger = ServiceLocator.shared.getLogger()

        func invokeInternal(args: MXOResponseCodeRequest?) async -> ApiResult {
            do {
                if let request = args {
                    let mxoNative = ServiceLocator.shared.getMXONative()
                    let response = try await mxoNative.sendInteraction(responseCodeRequest: request)
                    logger.debug(e: nil) {
                        let responseString = String(describing: response)
                        return "Send Interaction Response Code Response: \(responseString)"
                    }
                    return ApiResult.JSObjectApiResult(response.toJs())
                } else {
                    return ApiResult.ErrorApiResult(ApiResult.Error(message: "Invalid MXOResponseCodeRequest", apiName: "InteractionBridge.SendInteractionResponseCode", cause: nil))
                }
            } catch {
                return ApiResult.ErrorApiResult(
                    ApiResult.Error(
                        message: "Error sending MXO Response Code.",
                        apiName: "InteractionBridge.SendInteractionResponseCode",
                        cause: error.localizedDescription
                    ))
            }
        }

        func adaptJson(jsObject: Dictionary<String, Any>?) -> MXOResponseCodeRequest? {
            do {
                return try jsObject?.toMxoResponseCodeRequest()
            } catch {
                logger.error(e: error) {
                    return "Error parsing JSON for MXOResponseCodeRequest."
                }
                return nil
            }
        }

        typealias ARGS = MXOResponseCodeRequest
    }

    private class SendInteractionForOutboundLink: ApiBridge {
        private let logger = ServiceLocator.shared.getLogger()

        func invokeInternal(args: URL?) async -> ApiResult {
            do {
                if let url = args {
                    let mxoNative = ServiceLocator.shared.getMXONative()
                    try await mxoNative.sendInteraction(forOutboundLink: url)
                    logger.debug(e: nil) {
                        return "Send Interaction for Outbound Link: \(url)"
                    }
                    return ApiResult.NullApiResult
                } else {
                    return ApiResult.ErrorApiResult(ApiResult.Error(message: "Invalid Url. Send Interaction For Outbound Link Failed", apiName: "InteractionBridge.SendInteractionForOutboundLink", cause: nil))
                }
            } catch {
                return ApiResult.ErrorApiResult(
                    ApiResult.Error(
                        message: "Error Sending Interaction For Outbound Link",
                        apiName: "InteractionBridge.SendInteractionForOutboundLink",
                        cause: error.localizedDescription
                    ))
            }
        }

        func adaptJson(jsObject: Dictionary<String, Any>?) -> URL? {
            guard let json = jsObject, let value = json["value"] else {
                return nil
            }
            if let dict = value as? Dictionary<String, Any>,
                let url = dict["href"] as? String {
                return URL(string: url)
            }
            if let url = value as? String {
                return URL(string: url)
            }
            logger.error(e: nil) {
                return "Error parsing JSON for Outbound Link Url: \(String(describing: jsObject))"
            }
            return nil
        }

        typealias ARGS = URL
    }
}
