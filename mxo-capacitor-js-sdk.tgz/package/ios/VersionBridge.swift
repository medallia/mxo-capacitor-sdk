import Foundation
import MedalliaMXO

public class VersionBridge {
    public static let getter: any ApiBridge = Getter()
    
    private init() { }
    
    public class Getter : ApiBridge {
        public typealias ARGS = Any
        
        private let logger = ServiceLocator.shared.getLogger()
        
        public func invokeInternal(args: ARGS?) async -> ApiResult {
            do {
                let mxoNative = ServiceLocator.shared.getMXONative()
                let version = try mxoNative.getVersion() + "-" + MXOConstants.MXO_SDK_VERSION
                logger.debug(e: nil) {
                    return "Version: \(version)"
                }
                return ApiResult.StringApiResult(version)
            } catch {
                logger.error(e: error, msg: nil)
                return ApiResult.ErrorApiResult(
                    ApiResult.Error(
                        message: "Error getting MXO Version.",
                        apiName: "VersionBridge.Getter",
                        cause: error.localizedDescription
                    ))
            }
        }
        
        public func adaptJson(jsObject: Dictionary<String, Any>?) -> ARGS? {
            // ignored since its a getter
            return nil
        }
    }
}
