import Foundation

public protocol Logger {
    func debug(e: Error?, msg: (() -> String)?)
    func error(e: Error?, msg: (() -> String)?)
}
